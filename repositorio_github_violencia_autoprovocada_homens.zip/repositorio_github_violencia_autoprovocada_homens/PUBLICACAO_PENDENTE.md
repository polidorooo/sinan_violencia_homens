# Antes de publicar no GitHub

- [ ] Conectar a conta GitHub ao ChatGPT (necessário para criar o repositório em nome do titular).
- [ ] Confirmar o nome e a visibilidade do repositório; sugerido `sinan-violencia-autoprovocada-homens-2015-2024`, inicialmente **privado** para revisão.
- [ ] Verificar se os scripts disponibilizados coincidem com os executados no Google Colab na versão definitiva do artigo.
- [ ] Adicionar a etapa de consolidação `VIOLBR*.dbc` → `SINAN_VIOLENCIA_2015_2024.parquet` ou explicar como obtê-la; adicionar roteiro de extração dos denominadores SIDRA.
- [ ] Revisar a autoria, título definitivo e selecionar uma licença de código com os autores.
- [ ] Publicar (tornar público), verificar os arquivos e copiar a URL definitiva para o artigo.
- [ ] Se necessário, criar release com DOI via Zenodo para arquivamento citável.
