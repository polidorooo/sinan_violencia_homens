# Notificações de violência autoprovocada em pessoas do sexo masculino no Brasil (2015–2024)

Código de processamento, auditoria e análise epidemiológica usado em um estudo descritivo de notificações do Sistema de Informação de Agravos de Notificação (SINAN), com comparação de taxas por raça/cor em 2022 utilizando o Censo Demográfico do IBGE.

> **Unidade de análise:** notificação, e não pessoa. Os códigos de sexo do sistema não permitem confirmar identidade de gênero. As taxas representam **notificações**, não a incidência real de autolesão ou tentativa de suicídio.

## Ambiente

Os códigos foram preparados para **Google Colab / Python 3.13**. As bibliotecas são listadas em `requirements.txt`; no Colab, instalar eventuais dependências ausentes antes da execução.

```python
%pip install -q -r requirements.txt
```

> Se executar o comando no Colab, carregue `requirements.txt` em `/content` ou ajuste o caminho; alternativamente instale as bibliotecas necessárias diretamente. Em particular, o Script 02 requer `XlsxWriter`.

## Dados de entrada (não distribuídos neste repositório)

1. `/content/SINAN_VIOLENCIA_2015_2024.parquet`: versão consolidada, a partir dos arquivos públicos anuais do SINAN/VIVA de 2015 a 2024. O arquivo deve preservar, entre outras, as colunas `ANO_ARQUIVO`, `CS_SEXO`, `LES_AUTOP`, `CS_RACA` e os campos analisados nas fichas de violência.
2. `/content/censo2022_homens_uf_raca_idade.csv`: denominadores masculinos extraídos/organizados da [tabela SIDRA 9606](https://sidra.ibge.gov.br/tabela/9606), por UF, raça/cor e faixa etária.

**Limitação da disponibilização inicial:** estes scripts partem do Parquet consolidado e da tabela censitária organizada. A rotina de extração e consolidação dos arquivos SINAN `.dbc` para o Parquet e a rotina de construção do CSV do IBGE **não estão incluídas nesta versão**; portanto, o pacote ainda não garante reprodução integral desde os arquivos brutos. Essas etapas deverão ser adicionadas antes de se declarar reprodutibilidade completa a partir das fontes primárias.

## Ordem de execução

| Script | Finalidade | Entrada principal | Saída principal |
| --- | --- | --- | --- |
| `01_Tabela_1_FINAL_Colab_v04` | Caracterização, completude, qui-quadrado e V de Cramér | Parquet | Tabela 1 (`.xlsx`) |
| `02_Auditoria_Criterios_Autoprovocada_Colab` | Concordância `LES_AUTOP` × `REL_PROPRI` e análises de sensibilidade | Parquet | Auditoria (`.xlsx`) |
| `03_Taxas_2022_SINAN_Censo_Colab` | Taxas brutas, padronizadas e IC95%, Brasil/UF/raça | Parquet + CSV IBGE | `03_taxas_violencia_autoprovocada_2022.xlsx` |
| `03B_Tabela_2_Regioes_p_2022_Colab` | Tabela 2 por grandes regiões, testes condicionais por idade | Excel do Script 03 | Tabela 2 (`.xlsx`) |
| `04_Figura1_SerieTemporal_Colab_v2` | Figura 1, frequências anuais por raça/cor; BR/US, SVG/JPEG | Parquet | Figura 1 e base (`.xlsx`/`.csv`) |
| `05_Tabela_S1_Taxas_UF_Colab` | Tabela suplementar S1, taxas por UF | Excel do Script 03 | Tabela S1 (`.xlsx`) |
| `06_Dados_Numericos_Figura_1_Colab` | Tabela com valores anuais exatos da Figura 1 | Parquet | Dados numéricos (`.xlsx`) |

Cada script está em `.ipynb` (Google Colab) e `.py` (Python). Os scripts usam os caminhos e nomes indicados nos respectivos cabeçalhos; execute-os em ordem, respeitando as entradas produzidas nas etapas anteriores.

## Notas metodológicas

- Seleção principal: `CS_SEXO = 'M'` e `LES_AUTOP = '1'`.
- Grupos raciais: brancos (`CS_RACA=1`), negros (pretos+pardos; códigos 2+4) e indígenas (código 5). As demais categorias integram os totais quando aplicável.
- A Tabela 1 utiliza notificações de 2015–2024; a Tabela 2 e a Tabela S1 utilizam 2022.
- Padronização direta por idade: população masculina brasileira do Censo 2022.
- IC95% das taxas brutas: Poisson exato; das padronizadas: gama de Fay–Feuer.
- As análises de associação e de comparação de taxas são exploratórias; os registros não são necessariamente independentes e pode haver subnotificação e preenchimento diferencial.
- Os produtos finais para o artigo devem ser **gerados no Google Colab**, com verificação dos controles analíticos. Este repositório contém scripts, não substitui as etapas de execução e validação.

## Privacidade e conteúdo excluído

Este repositório **não contém** o Parquet do SINAN, os arquivos `.dbc`, dados individuais, arquivos locais de resultados, credenciais ou tokens. O arquivo `.gitignore` ajuda a impedir que essas entradas e saídas sejam incluídas acidentalmente.

## Referências dos dados

- Ministério da Saúde / DATASUS. SINAN — notificações de violência interpessoal e autoprovocada, 2015–2024.
- Instituto Brasileiro de Geografia e Estatística (IBGE). Censo Demográfico 2022, tabela SIDRA 9606.

## Citação e licenciamento

Este repositório foi preparado para dar transparência aos códigos da pesquisa. Informações bibliográficas do artigo (título definitivo, periódico, DOI), os nomes da autoria e a licença de reutilização deverão ser adicionados após confirmação dos autores. **Nenhuma licença de software é concedida explicitamente neste pacote inicial.**
