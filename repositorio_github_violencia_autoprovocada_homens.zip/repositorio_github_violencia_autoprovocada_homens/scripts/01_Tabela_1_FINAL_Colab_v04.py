# ================================================================
# ARTIGO — VIOLÊNCIA AUTOPROVOCADA EM HOMENS, BRASIL, 2015–2024
# SCRIPT 01 v4 | TABELA 1 FINAL: CARACTERIZAÇÃO + p + V DE CRAMÉR
# Executar diretamente em UMA célula do Google Colab.
# Entrada: /content/SINAN_VIOLENCIA_2015_2024.parquet
# Saída:   /content/RESULTADOS_ARTIGO/01_tabelas/
# Não altera os arquivos de entrada.
# ================================================================

from pathlib import Path
from datetime import datetime
import platform
import pandas as pd
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq
import openpyxl
import scipy
from scipy.stats import chi2_contingency, random_table
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from IPython.display import display

ORIGEM = Path('/content/SINAN_VIOLENCIA_2015_2024.parquet')
DESTINO = Path('/content/RESULTADOS_ARTIGO/01_tabelas')
DESTINO.mkdir(parents=True, exist_ok=True)
EXCEL = DESTINO / 'Tabela_1_FINAL_caracterizacao_completude_p_V_2015_2024_v04.xlsx'

if not ORIGEM.exists():
    raise FileNotFoundError(f'Parquet não encontrado: {ORIGEM}')

# 1. LEITURA SELETIVA (O PARQUET ORIGINAL PERMANECE INTACTO)
pf = pq.ParquetFile(str(ORIGEM))
colunas = [
    'ANO_ARQUIVO','DT_NOTIFIC','CS_SEXO','LES_AUTOP','CS_RACA',
    'NU_IDADE_N','ORIENT_SEX','CS_ESCOL_N','OUT_VEZES','LOCAL_OCOR',
    'AG_ENVEN','AG_ENFOR','AG_CORTE','AG_FOGO','ID_MN_RESI',
    'REL_PROPRI','IDENT_GEN'
]
faltando = sorted(set(colunas)-set(pf.schema_arrow.names))
if faltando:
    raise ValueError(f'Campos obrigatórios ausentes do Parquet: {faltando}')

partes = []
for lote in pf.iter_batches(columns=colunas, batch_size=120_000):
    df = lote.to_pandas()
    sexo = df['CS_SEXO'].astype('string').str.strip().str.upper()
    autop = df['LES_AUTOP'].astype('string').str.strip()
    df = df.loc[(sexo == 'M').fillna(False) & (autop == '1').fillna(False)].copy()
    if len(df): partes.append(df)
if not partes:
    raise ValueError('Nenhum registro com CS_SEXO=M e LES_AUTOP=1.')
base = pd.concat(partes, ignore_index=True)
del partes

# Dicionário SINAN: códigos com zero à esquerda são equivalentes.
def codigo(s):
    return (s.astype('string').fillna('').str.strip()
             .str.replace(r'^0+(?=\d)', '', regex=True))

for nome in ['CS_RACA','ORIENT_SEX','CS_ESCOL_N','OUT_VEZES',
             'LOCAL_OCOR','AG_ENVEN','AG_ENFOR','AG_CORTE',
             'AG_FOGO','REL_PROPRI','IDENT_GEN']:
    base[nome] = codigo(base[nome])

base['ANO'] = pd.to_numeric(base['ANO_ARQUIVO'], errors='coerce')
if base['ANO'].isna().any() or (~base['ANO'].between(2015,2024)).any():
    raise ValueError('ANO_ARQUIVO inválido ou fora de 2015–2024.')
base['ANO'] = base['ANO'].astype(int)

# Verificação temporal: não alterar o ano silenciosamente.
datatexto = base['DT_NOTIFIC'].astype('string').fillna('').str.strip()
ano_data = pd.to_numeric(datatexto.str.extract(r'^(20\d{2})')[0], errors='coerce')
base['DATA_ANO_INVALIDO'] = ano_data.isna()
base['ANO_DIVERGENTE'] = ano_data.notna() & ano_data.ne(base['ANO'])

# 2. IDADE: primeiro dígito = unidade (1 hora, 2 dia, 3 mês, 4 ano)
s = base['NU_IDADE_N'].astype('string').fillna('').str.strip()
formato = s.str.fullmatch(r'[1-4]\d{3}').fillna(False)
unidade = s.str.slice(0,1)
quantidade = pd.to_numeric(s.str.slice(1), errors='coerce')
anos = pd.Series(np.nan, index=base.index, dtype='float64')
for u, maximo in [('1',23),('2',31),('3',11)]:
    mask = formato & unidade.eq(u) & quantidade.between(0,maximo)
    anos.loc[mask] = 0
mask = formato & unidade.eq('4') & quantidade.between(0,120)
anos.loc[mask] = quantidade.loc[mask]
base['IDADE_ANOS'] = anos
# OITO FAIXAS ETÁRIAS: correspondem exatamente à união das faixas
# quinquenais da tabela 9606 (Censo 2022). A faixa 15–29 foi
# desagregada em 15–19, 20–24 e 25–29; 0–14 foi separada
# em 0–9 e 10–14 para distinguir crianças pequenas e adolescentes.
FAIXAS_IDADE = [
    '0–9', '10–14', '15–19', '20–24',
    '25–29', '30–44', '45–59', '60+'
]
base['FAIXA'] = pd.cut(
    anos,
    bins=[-1,9,14,19,24,29,44,59,np.inf],
    labels=FAIXAS_IDADE
).astype('string').fillna('Idade ignorada/inválida')

# Auditoria de consistência para a nova classificação.
validas_idade = base['IDADE_ANOS'].notna()
assert base.loc[validas_idade, 'FAIXA'].isin(FAIXAS_IDADE).all()
assert base.loc[~validas_idade, 'FAIXA'].eq('Idade ignorada/inválida').all()

# 3. RAÇA/COR E UF DE RESIDÊNCIA
racas = {'1':'Brancos','2':'Negros','4':'Negros','5':'Indígenas','3':'Amarelos'}
base['RACA'] = base['CS_RACA'].map(racas).fillna('Não classificada')
ufs = {'11':'RO','12':'AC','13':'AM','14':'RR','15':'PA','16':'AP','17':'TO',
       '21':'MA','22':'PI','23':'CE','24':'RN','25':'PB','26':'PE','27':'AL',
       '28':'SE','29':'BA','31':'MG','32':'ES','33':'RJ','35':'SP','41':'PR',
       '42':'SC','43':'RS','50':'MS','51':'MT','52':'GO','53':'DF'}
municipio = base['ID_MN_RESI'].astype('string').fillna('').str.strip()
codigo_uf = municipio.str.extract(r'^(\d{2})(?:\d{4}|\d{5})$')[0]
base['UF'] = codigo_uf.map(ufs).fillna('SEM_UF')

# 4. DICIONÁRIOS DE CARACTERIZAÇÃO
base['ORIENTACAO'] = base['ORIENT_SEX'].map({
    '1':'Heterossexual','2':'Homossexual','3':'Bissexual',
    '8':'Não se aplica','9':'Ignorado/não informado'
}).fillna('Ignorado/não informado')

escolar = {
    '0':'Analfabeto/sem instrução',
    '1':'Fundamental incompleto','2':'Fundamental incompleto',
    '3':'Fundamental incompleto','4':'Fundamental completo',
    '5':'Médio incompleto','6':'Médio completo',
    '7':'Superior incompleto/completo','8':'Superior incompleto/completo'
}
base['ESCOLARIDADE'] = base['CS_ESCOL_N'].map(escolar).fillna('Ignorado/não informado/inválido')
base['RECORRENCIA'] = base['OUT_VEZES'].map({'1':'Sim','2':'Não'}).fillna('Ignorado/não informado')
base['LOCAL'] = base['LOCAL_OCOR'].map({
    '1':'Residência','6':'Via pública',
    **{str(k):'Outros locais' for k in [2,3,4,5,7,8,9]}
}).fillna('Ignorado/não informado')

# 5. ELEGIBILIDADE E COMPLETUDE
# Orientação sexual é aplicável a partir de 10 anos;
# escolaridade é aplicável a partir de 7 anos (SINAN NET).
eleg_orient = base['IDADE_ANOS'].ge(10)
eleg_escola = base['IDADE_ANOS'].ge(7)

validade = {
    'Raça/cor': base['CS_RACA'].isin(['1','2','3','4','5']),
    'Faixa etária': base['IDADE_ANOS'].notna(),
    'Orientação sexual (≥10 anos)': base['ORIENT_SEX'].isin(['1','2','3']),
    'Escolaridade (≥7 anos)': base['CS_ESCOL_N'].isin([str(x) for x in range(9)]),
    'Recorrência': base['OUT_VEZES'].isin(['1','2']),
    'Local de ocorrência': base['LOCAL_OCOR'].isin([str(x) for x in range(1,10)]),
    'Envenenamento/intoxicação': base['AG_ENVEN'].isin(['1','2']),
    'Enforcamento': base['AG_ENFOR'].isin(['1','2']),
    'Objeto perfurocortante': base['AG_CORTE'].isin(['1','2']),
    'Arma de fogo': base['AG_FOGO'].isin(['1','2'])
}
elegibilidade = {
    nome: (eleg_orient if nome.startswith('Orientação sexual')
           else eleg_escola if nome.startswith('Escolaridade')
           else pd.Series(True,index=base.index))
    for nome in validade
}

# Percentuais de completude são calculados entre registros elegíveis.
def comp(nome, mascara):
    elig = (elegibilidade[nome] & mascara).fillna(False)
    n = int(elig.sum())
    valid = int((elig & validade[nome]).sum())
    return valid, n, (100*valid/n if n else np.nan)

# 6. TABELA 1: n (%) COM DENOMINADORES EXPLÍCITOS
subgrupos = ['Total','Brancos','Negros','Indígenas']
mascaras = {'Total':pd.Series(True,index=base.index)}
for r in subgrupos[1:]: mascaras[r] = base['RACA'].eq(r)

def br_int(n): return f'{int(n):,}'.replace(',','.')
def br_pct(n): return f'{n:.1f}'.replace('.',',')
def celula(n,den):
    return f'{br_int(n)} ({br_pct(100*n/den)}%)' if den else '—'

tabela = []
def bloco(titulo, var_comp, extra_elig=None):
    counts = []
    for grupo in subgrupos:
        mask = mascaras[grupo] & (elegibilidade[var_comp] if extra_elig is None else extra_elig)
        counts.append(int(mask.sum()))
    _,_,c = comp(var_comp,mascaras['Total'])
    tabela.append([titulo] + [br_int(n) for n in counts] + [br_pct(c) if pd.notna(c) else '—'])
    return [mascaras[grupo] & (elegibilidade[var_comp] if extra_elig is None else extra_elig)
            for grupo in subgrupos]

def linha(rotulo, mascara_evento, denoms, completude=None):
    vals = []
    for den in denoms:
        vals.append(celula(int((den & mascara_evento).sum()), int(den.sum())))
    tabela.append(['   ' + rotulo]+vals+[completude if completude is not None else ''])

# Linha geral
n_total = len(base)
tabela.append(['Notificações analisadas, n'] +
              [br_int(int(mascaras[g].sum())) for g in subgrupos] + [''])
_,_,cr = comp('Raça/cor',mascaras['Total'])
tabela.append(['Raça/cor — completude geral'] + ['']*4 + [br_pct(cr)])

elig = bloco('Faixa etária','Faixa etária')
for faixa in FAIXAS_IDADE + ['Idade ignorada/inválida']:
    linha(faixa,base['FAIXA'].eq(faixa),elig)

elig = bloco('Orientação sexual (somente ≥10 anos)','Orientação sexual (≥10 anos)')
for categoria in ['Heterossexual','Homossexual','Bissexual',
                  'Não se aplica','Ignorado/não informado']:
    linha(categoria,base['ORIENTACAO'].eq(categoria),elig)

elig = bloco('Escolaridade (somente ≥7 anos)','Escolaridade (≥7 anos)')
for categoria in ['Analfabeto/sem instrução','Fundamental incompleto',
                  'Fundamental completo','Médio incompleto','Médio completo',
                  'Superior incompleto/completo','Ignorado/não informado/inválido']:
    linha(categoria,base['ESCOLARIDADE'].eq(categoria),elig)

elig = bloco('Recorrência','Recorrência')
for categoria in ['Sim','Não','Ignorado/não informado']:
    linha(categoria,base['RECORRENCIA'].eq(categoria),elig)

elig = bloco('Local de ocorrência','Local de ocorrência')
for categoria in ['Residência','Via pública','Outros locais','Ignorado/não informado']:
    linha(categoria,base['LOCAL'].eq(categoria),elig)

# Os meios são campos simultâneos (multirresposta); % = todos registros do grupo.
tabela.append(['Meios utilizados (respostas múltiplas)','','','','',''])
for nome,col in [('Envenenamento/intoxicação','AG_ENVEN'),
                 ('Enforcamento','AG_ENFOR'),
                 ('Objeto perfurocortante','AG_CORTE'),
                 ('Arma de fogo','AG_FOGO')]:
    _,_,c = comp(nome,mascaras['Total'])
    denoms = [mascaras[g] for g in subgrupos]
    linha(nome,base[col].eq('1'),denoms,br_pct(c) if pd.notna(c) else '—')

# 7. TABELAS DE COMPLETUDE (ANO E UF)
colunas_qc = list(validade.keys())
def quadro_qualidade(chave, recorte=None):
    recorte = pd.Series(True,index=base.index) if recorte is None else recorte
    resultados = []
    for valor, indices in base.loc[recorte].groupby(chave, dropna=False).groups.items():
        mask = pd.Series(False,index=base.index)
        mask.loc[indices] = True
        linha_q = {chave:valor, 'Notificações (n)':int(mask.sum())}
        for nome in colunas_qc:
            valid,n,pct = comp(nome,mask)
            linha_q[f'{nome}: elegíveis (n)'] = n
            linha_q[f'{nome}: válidos (n)'] = valid
            linha_q[f'{nome}: completude (%)'] = round(pct,2) if pd.notna(pct) else None
        resultados.append(linha_q)
    return pd.DataFrame(resultados).sort_values(chave)

qual_ano = quadro_qualidade('ANO')
qual_uf = quadro_qualidade('UF',base['ANO'].eq(2022))

# 8. CONTROLES DE CONSISTÊNCIA
n_anual = base.groupby('ANO').size()
if n_anual.sum()!=n_total or set(n_anual.index)!=set(range(2015,2025)):
    raise AssertionError('Falha na composição da série 2015–2024.')
if (sum(int(mascaras[g].sum()) for g in ['Brancos','Negros','Indígenas'])
    + int(base['RACA'].eq('Amarelos').sum())
    + int(base['RACA'].eq('Não classificada').sum())) != n_total:
    raise AssertionError('Erro nos totais por raça/cor.')
for nome in colunas_qc:
    valid,eligivel,_ = comp(nome,mascaras['Total'])
    if not (0<=valid<=eligivel<=n_total):
        raise AssertionError(f'Falha de completude: {nome}')

# Nunca descartar categorias sem documentar.
controles = [
    ('Parquet: total de registros de todos os tipos',int(pf.metadata.num_rows)),
    ('Notificações masculinas autoprovocadas 2015–2024',n_total),
    ('Notificações selecionadas em 2022',int(base['ANO'].eq(2022).sum())),
    ('Brancos',int(mascaras['Brancos'].sum())),
    ('Negros (pretos e pardos)',int(mascaras['Negros'].sum())),
    ('Indígenas',int(mascaras['Indígenas'].sum())),
    ('Amarelos',int(base['RACA'].eq('Amarelos').sum())),
    ('Raça ignorada/não classificada',int(base['RACA'].eq('Não classificada').sum())),
    ('Ano da data de notificação inválido/não interpretado',int(base['DATA_ANO_INVALIDO'].sum())),
    ('Divergência ano da notificação × ano do arquivo',int(base['ANO_DIVERGENTE'].sum())),
    ('UF de residência inválida/não informada',int(base['UF'].eq('SEM_UF').sum())),
    ('Orientação não aplicável (<10 anos)',int((base['IDADE_ANOS']<10).sum())),
    ('Escolaridade não aplicável (<7 anos)',int((base['IDADE_ANOS']<7).sum())),
    ('Idade inválida (elegibilidade não definida)',int(base['IDADE_ANOS'].isna().sum())),
    ('Lesão autoprovocada com REL_PROPRI=2',int(base['REL_PROPRI'].eq('2').sum())),
    ('Lesão autoprovocada com REL_PROPRI ignorada/vazia',int((~base['REL_PROPRI'].isin(['1','2'])).sum())),
    ('PyArrow',pa.__version__),('Pandas',pd.__version__),('SciPy',scipy.__version__),
    ('Python',platform.python_version()),('Execução',datetime.now().isoformat(timespec='seconds'))
]

# Conferência de que a reclassificação não alterou o recorte de registros
assert int(base['FAIXA'].isin(FAIXAS_IDADE).sum()) + int(base['FAIXA'].eq('Idade ignorada/inválida').sum()) == n_total

# 9. TESTES DE ASSOCIAÇÃO ENTRE OS TRÊS GRUPOS RACIAIS + V DE CRAMÉR
# Testes: qui-quadrado de Pearson (3 x k) com frequências observadas;
# se algum E<1 ou mais de 20% das células tiverem E<5, usar teste
# de Monte Carlo condicional às margens (tabela RxC; 20.000 simulações).
# IMPORTANTE: ignorados/inválidos ficam na descrição e na completude,
# mas NÃO entram nos testes. Meios: compara SIM e NÃO válidos.
# Valores de p são exploratórios: podem existir notificações repetidas por
# pessoa; os testes não controlam essa dependência nem confundimento.

GRUPOS_TESTE = ['Brancos','Negros','Indígenas']
N_SIMS = 20_000
SEMENTE = 20261104
resultados_testes = []
valores_p_por_rotulo = {}
valores_v_por_rotulo = {}

def testar_associacao(rotulo, serie_categorias, categorias, elegiveis, observacao=''):
    mascara = (
        base['RACA'].isin(GRUPOS_TESTE)
        & elegiveis.fillna(False)
        & serie_categorias.isin(categorias)
    )
    cruzamento = pd.crosstab(
        base.loc[mascara,'RACA'],
        serie_categorias.loc[mascara]
    ).reindex(index=GRUPOS_TESTE, columns=categorias, fill_value=0)

    # Manter somente colunas com observação; categorias sem registros
    # não contribuem para o teste e podem provocar esperados iguais a 0.
    cruzamento = cruzamento.loc[:, cruzamento.sum(axis=0)>0]
    n = int(cruzamento.to_numpy().sum())
    n_por_grupo = [int(x) for x in cruzamento.sum(axis=1).tolist()]
    resultado = {
        'Bloco / variável':rotulo,
        'Categorias testadas':' | '.join(cruzamento.columns.tolist()),
        'Grupos comparados':'Brancos | Negros | Indígenas',
        'N total no teste':n,
        'N brancos':n_por_grupo[0],
        'N negros':n_por_grupo[1],
        'N indígenas':n_por_grupo[2],
        'Método':'Não calculado',
        'Qui-quadrado de Pearson':np.nan,
        'Graus de liberdade':np.nan,
        'p (numérico)':np.nan,
        'p (BR)': '—',
        'V de Cramér':np.nan,
        'Menor frequência esperada':np.nan,
        'Células E<5 (n)':np.nan,
        'Células E<5 (%)':np.nan,
        'Simulações Monte Carlo':0,
        'Observação':observacao
    }

    if n == 0 or cruzamento.shape[1]<2 or (cruzamento.sum(axis=1)==0).any():
        resultado['Observação'] += ' | Teste não estimável: tabela degenerada.'
        resultados_testes.append(resultado)
        valores_p_por_rotulo[rotulo] = '—'
        valores_v_por_rotulo[rotulo] = '—'
        return

    obs = cruzamento.to_numpy(dtype=np.int64)
    qui2, p_assint, gl, esperado = chi2_contingency(obs, correction=False)
    raro = int((esperado<5).sum())
    raro_pct = 100*raro/esperado.size
    esparsa = bool((esperado<1).any() or raro_pct>20)
    p = float(p_assint)
    metodo = 'Qui-quadrado de Pearson (assintótico)'
    sim = 0

    if esparsa:
        # Sorteio de tabelas com as mesmas margens observadas.
        # Estatística e frequências esperadas permanecem as de Pearson.
        margens_linhas = obs.sum(axis=1)
        margens_colunas = obs.sum(axis=0)
        gerador = np.random.default_rng(SEMENTE)
        extremos = 0
        for _ in range(N_SIMS//1000):
            amostras = random_table.rvs(margens_linhas,margens_colunas,
                                       size=1000,random_state=gerador)
            chi_sim = ((amostras-esperado)**2/esperado).sum(axis=(1,2))
            extremos += int((chi_sim >= qui2-1e-12).sum())
        p = (extremos+1)/(N_SIMS+1)
        sim = N_SIMS
        metodo = 'Qui-quadrado de Pearson, p por Monte Carlo (margens fixas)'

    p_br = ('p < 0,001' if p<0.001 else 'p = '+f'{p:.3f}'.replace('.',','))
    v = (qui2/(n*min(obs.shape[0]-1,obs.shape[1]-1)))**0.5
    resultado.update({
        'Método':metodo,
        'Qui-quadrado de Pearson':round(float(qui2),6),
        'Graus de liberdade':int(gl),
        'p (numérico)':p,
        'p (BR)':p_br,
        'V de Cramér':round(float(v),6),
        'Menor frequência esperada':round(float(esperado.min()),4),
        'Células E<5 (n)':raro,
        'Células E<5 (%)':round(raro_pct,2),
        'Simulações Monte Carlo':sim,
        'Observação':observacao
    })
    resultados_testes.append(resultado)
    valores_p_por_rotulo[rotulo] = p_br
    valores_v_por_rotulo[rotulo] = f'{v:.3f}'.replace('.', ',')

# Idade: excluir somente idade inválida
# Não excluir menores de 10 anos na comparação etária.
testar_associacao('Faixa etária',base['FAIXA'],FAIXAS_IDADE,
                  pd.Series(True,index=base.index),
                  'Idades inválidas excluídas do teste, mas apresentadas na tabela.')

# Orientação sexual: idade >=10 e códigos 1,2,3 somente.
testar_associacao('Orientação sexual (somente ≥10 anos)',base['ORIENTACAO'],
                  ['Heterossexual','Homossexual','Bissexual'],eleg_orient,
                  'Não se aplica, ignorado e vazio excluídos do teste.')

# Escolaridade: idade >=7 e categorias válidas dos códigos 0..8.
testar_associacao('Escolaridade (somente ≥7 anos)',base['ESCOLARIDADE'],
                  ['Analfabeto/sem instrução','Fundamental incompleto',
                   'Fundamental completo','Médio incompleto','Médio completo',
                   'Superior incompleto/completo'],eleg_escola,
                  'Ignorado, vazio e código inválido excluídos do teste.')

testar_associacao('Recorrência',base['RECORRENCIA'],['Sim','Não'],
                  pd.Series(True,index=base.index),
                  'Ignorado e vazio excluídos do teste.')

testar_associacao('Local de ocorrência',base['LOCAL'],
                  ['Residência','Via pública','Outros locais'],
                  pd.Series(True,index=base.index),
                  'Ignorado e vazio excluídos do teste.')

# Meios são campos independentes de resposta múltipla.
for rotulo,col in [('Envenenamento/intoxicação','AG_ENVEN'),
                   ('Enforcamento','AG_ENFOR'),
                   ('Objeto perfurocortante','AG_CORTE'),
                   ('Arma de fogo','AG_FOGO')]:
    resposta = base[col].map({'1':'Sim','2':'Não'}).fillna('Ignorado')
    testar_associacao(rotulo,resposta,['Sim','Não'],
                      pd.Series(True,index=base.index),
                      'Teste sim/não entre registros com resposta válida. '
                      'O n (%) publicado usa todos os registros do grupo.')

testes_df = pd.DataFrame(resultados_testes)
assert len(testes_df)==9
assert testes_df['N total no teste'].le(n_total).all()
assert testes_df['N total no teste'].gt(0).all()
assert testes_df['p (numérico)'].between(0,1).all()

# Tabela de publicação: "p" e "V de Cramér" aparecem SOMENTE na linha
# da variável/bloco; não são repetidos nas subcategorias.
# Meios utilizados: testes binários próprios em cada linha.
# Preservamos integralmente as seis colunas descritivas originais.
tabela_final = []
for linha_original in tabela:
    rotulo = str(linha_original[0]).strip()
    tabela_final.append(
        linha_original + [valores_p_por_rotulo.get(rotulo, ''),
                         valores_v_por_rotulo.get(rotulo, '')]
    )
assert all(len(x)==8 for x in tabela_final)

# Controles: garantir a presença dos nove testes nas linhas corretas.
for rotulo in testes_df['Bloco / variável']:
    correspondencias = [r for r in tabela_final if r[0].strip() == rotulo]
    assert len(correspondencias) == 1, f'Linha de teste ausente/duplicada: {rotulo}'
    assert correspondencias[0][-1] != '', f'V de Cramér não registrado: {rotulo}'

# Reconciliar com o universo auditado nas etapas anteriores sem forçar
# estes totais em testes funcionais com bases sintéticas diferentes.
if int(pf.metadata.num_rows) == 3_881_759:
    esperados = {
        'Total':334_638, 'Brancos':145_113,
        'Negros':156_743, 'Indígenas':2_757
    }
    for grupo, n_esperado in esperados.items():
        assert int(mascaras[grupo].sum()) == n_esperado, (
            f'Inconsistência em {grupo}: {int(mascaras[grupo].sum())} '
            f'≠ {n_esperado}'
        )
    assert int(base['ANO'].eq(2022).sum()) == 41_710, 'Inconsistência em 2022'
    assert abs(float(testes_df.loc[
        testes_df['Bloco / variável'].eq('Orientação sexual (somente ≥10 anos)'),
        'p (numérico)'].iloc[0]) - 0.2609319377813817) < 1e-5, (
            'Teste de orientação sexual divergente da versão anterior; conferir recodificações'
        )


# 9. EXPORTAR XLSX ESTILIZADO (VALORES EM FORMATO BR)
wb = openpyxl.Workbook()
ws = wb.active
ws.title = 'Tabela_1_Publicacao'
ws.append(['Caracterização das notificações de violência autoprovocada em homens — Brasil, 2015–2024'])
ws.append(['SINAN | Unidade de análise: notificação | percentuais por coluna e por bloco, conforme elegibilidade'])
ws.append([])
ws.append(['Variável / categoria','Total, n (%)','Brancos, n (%)',
           'Negros, n (%)','Indígenas, n (%)','Completude geral (%)',
           'Valor de p','V de Cramér'])
for linha_tab in tabela_final: ws.append(linha_tab)
ws.append([])
notas = [
    'Notas: Brancos=CS_RACA 1; negros=2+4; indígenas=5. O total inclui amarelos e registros sem raça/cor válida.',
    'Cada bloco inicia com o número de notificações elegíveis no total e em cada grupo; % das categorias usa esse N.',
    'Completude = campos válidos / registros elegíveis × 100. Raça/cor: códigos 1–5; idade: codificação válida.',
    'Orientação sexual: elegíveis idade ≥10; válidos códigos 1,2,3. Código 8 em ≥10 é exibido em “Não se aplica”, mas não conta como completo.',
    'Escolaridade: elegíveis idade ≥7; códigos 0–8 válidos; 9,10,vazio/outros não contam como completos.',
    'Recorrência e meios: códigos 1/2 válidos; local: 01–09 válidos. Ignorado/vazio/outros são incompletos.',
    'Meios: múltiplas respostas possíveis. n (%) é o número de “sim” dividido por todas as notificações do grupo.',
    'Faixas etárias: 0–9; 10–14; 15–19; 20–24; 25–29; 30–44; 45–59; 60+; idade inválida preservada.',
    'LOCAL_OCOR=09 é “Outro”; LOCAL_OCOR=99 é “Ignorado” e é excluído do cálculo de completude.',
    'A coluna “Completude geral” usa TODAS as notificações elegíveis, inclusive amarelos e raça/cor ignorada.',
    'Os resultados são notificações, não pessoas únicas nem incidência populacional de autolesão.',
    'Valor de p: associação global de raça/cor (brancos, negros, indígenas), usando categorias válidas; ignorados excluídos do teste.',
    'Qui-quadrado de Pearson; se pressupostos de contagem esperada inadequados, p por Monte Carlo com margens fixas (20.000 tabelas).',
    'Meios utilizados: p para Sim versus Não em cada campo; respostas múltiplas possíveis; percentuais da tabela usam todos os registros.',
    'V de Cramér: raiz de χ²/[n × min(linhas−1, colunas−1)]. Exibido com três casas decimais.',
    'Valores de p exploratórios: notificações não são necessariamente independentes, e testes não ajustam por confundimento.'
]
for nota in notas: ws.append([nota])
ws.freeze_panes = 'B5'
ws.sheet_view.showGridLines = False
ws.column_dimensions['A'].width = 47
for c in 'BCDE': ws.column_dimensions[c].width = 22
ws.column_dimensions['F'].width = 23
ws.column_dimensions['G'].width = 19
ws.column_dimensions['H'].width = 16
ws.merge_cells('A1:H1')
ws.merge_cells('A2:H2')
ws['A1'].font = Font(name='Aptos',size=13,bold=True,color='16324F')
ws['A2'].font = Font(name='Aptos',size=10,italic=True,color='4E6072')
for cell in ws[4]:
    cell.fill = PatternFill('solid',fgColor='18364F')
    cell.font = Font(color='FFFFFF',bold=True)
    cell.alignment = Alignment(wrap_text=True,vertical='center')
ws.row_dimensions[4].height = 30
blocos = ['Notificações analisadas','Raça/cor —','Faixa etária',
          'Orientação sexual (','Escolaridade (','Recorrência',
          'Local de ocorrência','Meios utilizados']
for r in range(5,5+len(tabela_final)):
    if any(str(ws.cell(r,1).value).startswith(t) for t in blocos):
        for cell in ws[r]:
            cell.fill = PatternFill('solid',fgColor='EAF1F5')
            cell.font = Font(bold=True,color='16324F')
    else:
        for cell in ws[r]: cell.font = Font(color='273849',size=10)
    for c in range(2,9): ws.cell(r,c).alignment=Alignment(horizontal='center')
for r in range(6+len(tabela_final), ws.max_row+1):
    ws.cell(r,1).font = Font(size=9,color='526271',italic=True)
    ws.merge_cells(start_row=r,start_column=1,end_row=r,end_column=8)

# Abas suplementares: os números continuam como números, não textos formatados.
def escrever_df(nome,df,largura_inicial=24):
    aba = wb.create_sheet(nome)
    aba.sheet_view.showGridLines=False
    aba.append(list(df.columns))
    for row in df.itertuples(index=False,name=None):
        aba.append([None if pd.isna(x) else (x.item() if isinstance(x,np.generic) else x)
                    for x in row])
    aba.freeze_panes='C2'
    aba.auto_filter.ref=aba.dimensions
    for cell in aba[1]:
        cell.fill=PatternFill('solid',fgColor='18364F')
        cell.font=Font(bold=True,color='FFFFFF')
        cell.alignment=Alignment(wrap_text=True,vertical='center')
    aba.row_dimensions[1].height=44
    for j,col in enumerate(df.columns,1):
        aba.column_dimensions[get_column_letter(j)].width = (18 if j==1 else largura_inicial)
        if str(col).endswith('(%)'):
            for rowi in range(2,aba.max_row+1):
                aba.cell(rowi,j).number_format='0.00'
    return aba

escrever_df('Testes_estatisticos',testes_df,27)
escrever_df('Completude_2015_2024',qual_ano)
escrever_df('Completude_UF_2022',qual_uf)

# ABA DE AUDITORIA ETÁRIA: N e % por grupo e faixa etária.
# Os percentuais incluem idade inválida no denominador do grupo,
# para não inflar silenciosamente os percentuais informados.
idade_registros = []
for nome_grupo in subgrupos:
    n_grupo = int(mascaras[nome_grupo].sum())
    for nome_faixa in FAIXAS_IDADE + ['Idade ignorada/inválida']:
        n_faixa = int((mascaras[nome_grupo] & base['FAIXA'].eq(nome_faixa)).sum())
        idade_registros.append({
            'Grupo racial': nome_grupo,
            'Faixa etária': nome_faixa,
            'Notificações (n)': n_faixa,
            'Percentual do grupo (%)': round(100*n_faixa/n_grupo,2) if n_grupo else None
        })
idade_df = pd.DataFrame(idade_registros)
for nome_grupo, grupo in idade_df.groupby('Grupo racial'):
    assert grupo['Notificações (n)'].sum() == int(mascaras[nome_grupo].sum())
escrever_df('Distribuicao_etaria',idade_df,26)

# Numeradores 2022 por UF, raça e oito faixas: servirão às taxas
# de 2022 e facilitarão a checagem de pequenas contagens indígenas.
# Não eliminamos idades ausentes nem UFs inválidas nesta aba.
num2022 = (base.loc[base['ANO'].eq(2022)]
           .groupby(['UF','RACA','FAIXA'], dropna=False)
           .size().reset_index(name='Notificações (n)'))
assert int(num2022['Notificações (n)'].sum()) == int(base['ANO'].eq(2022).sum())
escrever_df('Numeradores_2022_8faixas',num2022,22)

metadados = [
    ('DEFINIÇÃO','DESCRIÇÃO'),
    ('Fonte', 'SINAN NET — Violência interpessoal e autoprovocada, anos dos arquivos 2015–2024'),
    ('População', 'CS_SEXO=M e LES_AUTOP=1; todas as idades; unidade de análise: notificação'),
    ('Ano', 'ANO_ARQUIVO. Conferir divergências com DT_NOTIFIC antes de redigir Métodos.'),
    ('Raça/cor', 'Brancos=1; Negros=2+4; Indígenas=5; Amarelos=3; não classificada=9/vazio/outros.'),
    ('Idade', 'NU_IDADE_N decodificado em horas/dias/meses/anos; grupos 0–9,10–14,15–19,20–24,25–29,30–44,45–59,60+; idade inválida mantida.'),
    ('Orientação', 'Denominador: idade >=10. Completos apenas 1,2,3. Código 8 em >=10 não é válido.'),
    ('Escolaridade', 'Denominador: idade >=7. Completos apenas códigos 0 a 8.'),
    ('Meios', 'Múltiplas respostas; percentuais de “sim” entre todas as notificações do grupo.'),
    ('Percentuais Tabela 1', 'Denominador por coluna e bloco; incluem ignorado/inválido dentro dos elegíveis.'),
    ('Completude', 'Nº de respostas válidas dividido por Nº de elegíveis. Não equivale à precisão do dado.'),
    ('Relação racial', 'Total não é a soma das colunas principais, porque inclui amarelos e não classificados.'),
    ('Limitação', 'SINAN registra notificações e pode conter subnotificação e múltiplos registros por pessoa.'),
    ('IC95%', 'Não aplicável às contagens observadas da Tabela 1; taxas e razões de taxas terão IC95%.'),
    ('2022', 'Completude_UF_2022 e Numeradores_2022_8faixas incluem SEM_UF, preservando perdas territoriais.'),
    ('Mudança v2', 'Idade em oito categorias: 0–9, 10–14, 15–19, 20–24, 25–29, 30–44, 45–59, 60+. Nenhuma outra faixa ou denominador alterado.'),
    ('Local de ocorrência', 'LOCAL_OCOR 9 = Outros locais; 99 = Ignorado (nunca considerar válido).'),
    ('Comparações raciais v3', 'Qui-quadrado de Pearson: brancos vs negros vs indígenas; apenas respostas válidas, sem categoria ignorado. Um p por bloco; para meios, um p por campo binário.'),
    ('Pressupostos v3','Se qualquer esperada <1 ou >20% das esperadas <5: p de Monte Carlo condicional às margens, 20.000 simulações e semente 20261104.'),
    ('Independência v3','A unidade é a notificação; uma pessoa pode ter mais de uma notificação, limitando a interpretação inferencial dos valores de p.'),
    ('Apresentação v4','p < 0,001 ou p = x,xxx; V de Cramér = 0,xxx nas linhas de teste; zeros e categorias não aplicáveis excluídos somente dos testes.'),
    ('Material suplementar','As abas técnicas servem à reprodutibilidade, não são automaticamente tabelas suplementares a publicar.'),
]
metadados += [('CONTROLE: '+k,str(v)) for k,v in controles]
escrever_df('Dicionario_e_Controles',pd.DataFrame(metadados[1:],columns=metadados[0]),72)
wb.save(EXCEL)

# 10. RESUMO NA TELA
print('\n✓ Tabela 1 FINAL, valores de p, V de Cramér e relatórios técnicos gerados no Colab.')
print('Arquivo:',EXCEL)
print(f'Notificações elegíveis: {br_int(n_total)}')
print(f'Notificações de 2022: {br_int(int(base["ANO"].eq(2022).sum()))}')
print(f'Divergências ANO_ARQUIVO × DT_NOTIFIC: {br_int(int(base["ANO_DIVERGENTE"].sum()))}')
print('\nCOMPLETUDE GLOBAL — 2015–2024')
for nome in colunas_qc:
    v,n,pct=comp(nome,mascaras['Total'])
    print(f'  {nome}: {br_int(v)}/{br_int(n)} ({br_pct(pct) if pd.notna(pct) else "—"}%)')
print('\nPRIMEIRAS LINHAS DA TABELA 1')
display(pd.DataFrame(tabela_final,columns=['Variável / categoria','Total','Brancos','Negros','Indígenas','Completude (%)','Valor de p','V de Cramér']).head(16))
print('\nTESTES ESTATÍSTICOS:')
display(testes_df[['Bloco / variável','N total no teste','Método','p (BR)','V de Cramér','Menor frequência esperada']])
print('\nFAIXAS ETÁRIAS:')
print(' | '.join(FAIXAS_IDADE))
print('\nPróxima etapa: conferir a Tabela 1 final e preparar somente a Tabela S1 de taxas por UF.')
