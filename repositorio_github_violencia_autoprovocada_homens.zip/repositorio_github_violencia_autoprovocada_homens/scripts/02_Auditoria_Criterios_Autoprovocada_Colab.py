# -*- coding: utf-8 -*-
"""
Projeto: Violência autoprovocada entre homens, Brasil, 2015–2024.
SCRIPT 02 — Auditoria independente da definição operacional de lesão
             autoprovocada e da faixa etária 0–9 anos.

Entrada: /content/SINAN_VIOLENCIA_2015_2024.parquet
Saída:   /content/RESULTADOS_ARTIGO/02_auditoria/02_auditoria_criterios_autoprovocada.xlsx

IMPORTANTE: este script é diagnóstico; não modifica o Parquet e NÃO
altera os critérios da Tabela 1 sem decisão metodológica explícita.
"""

from pathlib import Path
import sys
import numpy as np
import pandas as pd
import pyarrow.parquet as pq

ENTRADA = Path('/content/SINAN_VIOLENCIA_2015_2024.parquet')
SAIDA = Path('/content/RESULTADOS_ARTIGO/02_auditoria')
SAIDA.mkdir(parents=True, exist_ok=True)
ARQUIVO_XLSX = SAIDA / '02_auditoria_criterios_autoprovocada.xlsx'

UF_CODIGOS = {
    '11':'RO','12':'AC','13':'AM','14':'RR','15':'PA','16':'AP','17':'TO',
    '21':'MA','22':'PI','23':'CE','24':'RN','25':'PB','26':'PE','27':'AL',
    '28':'SE','29':'BA','31':'MG','32':'ES','33':'RJ','35':'SP','41':'PR',
    '42':'SC','43':'RS','50':'MS','51':'MT','52':'GO','53':'DF'
}
UF_ORDENADAS = sorted(UF_CODIGOS.values()) + ['SEM_UF']
RACA_MAP = {'1':'Brancos','2':'Negros','4':'Negros','5':'Indígenas','3':'Amarelos'}
RACAS = ['Brancos','Negros','Indígenas','Amarelos','Não classificada']
STATUS = ['1 - Própria pessoa: sim', '2 - Própria pessoa: não',
          '9 - Ignorado', 'Vazio', 'Outro código']


def texto(s):
    return s.astype('string').str.strip().fillna('')


def decodificar_idade(s):
    """Anos completos; horas, dias ou meses elegíveis são idade 0.
    Preserva idades inválidas como NaN — NÃO imputar nem converter automaticamente.
    """
    s = texto(s)
    formato = s.str.fullmatch(r'[1-4][0-9]{3}', na=False)
    unidade = s.str[0]
    num = pd.to_numeric(s.str[1:4], errors='coerce')
    idade = pd.Series(np.nan, index=s.index, dtype='float64')
    for cod, maximo in [('1',23), ('2',30), ('3',11)]:
        mascara = (formato & unidade.eq(cod) & num.between(0,maximo)).fillna(False)
        idade.loc[mascara] = 0.0
    mascara_anos = (formato & unidade.eq('4') & num.between(0,120)).fillna(False)
    idade.loc[mascara_anos] = num.loc[mascara_anos].astype(float)
    return idade


def classificar_rel(s):
    return texto(s).map({
        '1': STATUS[0], '2': STATUS[1], '9': STATUS[2], '': STATUS[3]
    }).fillna(STATUS[4])


def tabela_cruzada(df, agrupador, ordem, inclui_idade=False):
    cruz = pd.crosstab(df[agrupador], df['REL_STATUS'])
    cruz = cruz.reindex(index=ordem, columns=STATUS, fill_value=0)
    cruz.insert(0, 'Total de notificações', cruz.sum(axis=1))
    cruz['Concordância explícita (%)'] = (
        100 * cruz[STATUS[0]] / cruz['Total de notificações'].replace(0,np.nan)
    ).round(2)
    cruz['Discordância explícita (%)'] = (
        100 * cruz[STATUS[1]] / cruz['Total de notificações'].replace(0,np.nan)
    ).round(2)
    cruz['Incompletude/fora de padrão (%)'] = (
        100 * (cruz[STATUS[2]] + cruz[STATUS[3]] + cruz[STATUS[4]])
        / cruz['Total de notificações'].replace(0,np.nan)
    ).round(2)
    if inclui_idade:
        cruz['Menores de 10 anos (n)'] = df.groupby(agrupador)['MENOR10'].sum().reindex(ordem, fill_value=0).astype(int)
        cruz['Idade inválida (n)'] = df.groupby(agrupador)['IDADE'].apply(lambda s: s.isna().sum()).reindex(ordem, fill_value=0).astype(int)
    return cruz.reset_index().rename(columns={agrupador:agrupador})


if not ENTRADA.exists():
    raise FileNotFoundError('Parquet não encontrado: ' + str(ENTRADA))

pf = pq.ParquetFile(str(ENTRADA))
nomes = set(pf.schema_arrow.names)
obrigatorias = ['ANO_ARQUIVO','CS_SEXO','LES_AUTOP','REL_PROPRI',
                'CS_RACA','NU_IDADE_N','ID_MN_RESI']
faltam = [c for c in obrigatorias if c not in nomes]
if faltam:
    raise ValueError(f'Colunas obrigatórias ausentes: {faltam}')

opcionais = [c for c in ['VIOL_OUTR','VIOL_ESPEC'] if c in nomes]
# Os demais campos REL_* informam possível preenchimento de OUTROS vínculos.
# Não são tratados como prova de violência interpessoal.
rel_adicionais = sorted(
    c for c in nomes if c.startswith('REL_')
    and c not in ('REL_PROPRI','REL_ESPEC')
)
colunas = obrigatorias + opcionais + rel_adicionais

print('SCRIPT 02 — AUDITORIA DE CONSISTÊNCIA E SENSIBILIDADE')
print('Parquet:', ENTRADA.name)
print('Registros no Parquet (metadados):', f'{pf.metadata.num_rows:,}')
print('Variáveis REL_* adicionais encontradas:', len(rel_adicionais))

partes = []
registros_lidos = 0
for i, batch in enumerate(pf.iter_batches(batch_size=100_000, columns=colunas),1):
    chunk = batch.to_pandas()
    registros_lidos += len(chunk)
    m = texto(chunk['CS_SEXO']).eq('M') & texto(chunk['LES_AUTOP']).eq('1')
    df = chunk.loc[m].copy()
    if df.empty:
        continue

    # A classificação racial preserva as categorias fora dos 3 grupos principais.
    raca = texto(df['CS_RACA'])
    idade = decodificar_idade(df['NU_IDADE_N'])
    rel = texto(df['REL_PROPRI'])
    municipio = texto(df['ID_MN_RESI'])
    uf2 = municipio.str.extract(r'^(\d{2})(?:\d{4}|\d{5})$')[0]

    out = pd.DataFrame({
        'ANO':pd.to_numeric(texto(df['ANO_ARQUIVO']),errors='raise').astype(int),
        'RACA':raca.map(RACA_MAP).fillna('Não classificada'),
        'UF':uf2.map(UF_CODIGOS).fillna('SEM_UF'),
        'REL_STATUS':classificar_rel(rel),
        'IDADE':idade,
    })
    out['MENOR10'] = out['IDADE'].lt(10).fillna(False)
    out['DEZ_MAIS'] = out['IDADE'].ge(10).fillna(False)
    out['OUTROS_VINCULOS_SIM'] = False
    if rel_adicionais:
        out['OUTROS_VINCULOS_SIM'] = pd.concat(
            [texto(df[c]).eq('1') for c in rel_adicionais],axis=1
        ).any(axis=1).to_numpy()

    out['VIOL_OUTR_SIM'] = (
        texto(df['VIOL_OUTR']).eq('1').to_numpy()
        if 'VIOL_OUTR' in opcionais else False
    )
    out['VIOL_ESPEC_PREENCHIDO'] = (
        texto(df['VIOL_ESPEC']).ne('').to_numpy()
        if 'VIOL_ESPEC' in opcionais else False
    )
    partes.append(out)
    if i % 5 == 0:
        print(f'  Lote {i:02d}: {registros_lidos:,} registros examinados')

if not partes:
    raise RuntimeError('Nenhuma notificação correspondente a CS_SEXO=M, LES_AUTOP=1.')

dados = pd.concat(partes,ignore_index=True)
del partes
N = len(dados)
N2022 = int(dados['ANO'].eq(2022).sum())
Nmenor = int(dados['MENOR10'].sum())
N10mais = int(dados['DEZ_MAIS'].sum())
Nidade_inv = int(dados['IDADE'].isna().sum())

if registros_lidos != pf.metadata.num_rows:
    raise AssertionError('Leitura incompleta do Parquet.')
if not dados['ANO'].between(2015,2024).all():
    raise AssertionError('Ano fora de 2015–2024: verifique ANO_ARQUIVO.')
if Nmenor + N10mais + Nidade_inv != N:
    raise AssertionError('A decomposição das idades não fecha.')
if dados['RACA'].value_counts().sum() != N:
    raise AssertionError('A decomposição racial não fecha.')

# 1. Concordância por ano / raça / UF em 2022.
por_ano = tabela_cruzada(dados,'ANO',list(range(2015,2025)),inclui_idade=True)
por_raca = tabela_cruzada(dados,'RACA',RACAS,inclui_idade=True)
ufs22 = tabela_cruzada(dados.loc[dados['ANO'].eq(2022)],'UF',UF_ORDENADAS,inclui_idade=True)

# 2. Menores de 10 anos, inclusive idades 0 registradas em horas/dias/meses.
menores = dados.loc[dados['MENOR10']].copy()
menores['IDADE_INTEIRA'] = menores['IDADE'].astype(int)
menores_por_idade = pd.crosstab(menores['IDADE_INTEIRA'],menores['RACA']).reindex(
    index=range(0,10),columns=RACAS,fill_value=0
)
menores_por_idade.insert(0,'Total',menores_por_idade.sum(axis=1))
menores_por_idade = menores_por_idade.reset_index().rename(columns={'IDADE_INTEIRA':'Idade (anos completos)'})
menores_por_ano = pd.crosstab(menores['ANO'],menores['RACA']).reindex(
    index=range(2015,2025),columns=RACAS,fill_value=0
)
menores_por_ano.insert(0,'Total',menores_por_ano.sum(axis=1))
menores_por_ano = menores_por_ano.reset_index()

# 3. Coerência auxiliar com campos 56 e 61. Não exportar textos livres.
aux = dados.groupby('REL_STATUS',observed=True).agg(
    **{
        'N notificações':('ANO','size'),
        'Outros vínculos marcados Sim (n)':('OUTROS_VINCULOS_SIM','sum'),
        'Tipo outros marcado Sim (n)':('VIOL_OUTR_SIM','sum'),
        'Especificação preenchida (n)':('VIOL_ESPEC_PREENCHIDO','sum'),
        'Menores 10 anos (n)':('MENOR10','sum'),
        'Idade não decodificável (n)':('IDADE',lambda x: int(x.isna().sum())),
    }
).reindex(STATUS,fill_value=0).reset_index()

# 4. Comparar critérios alternativos sem tomar decisões automáticas.
criterios = {
    'A — LES_AUTOP=1; todas idades (principal atual)':pd.Series(True,index=dados.index),
    'B — LES_AUTOP=1 e REL_PROPRI=1; todas idades':dados['REL_STATUS'].eq(STATUS[0]),
    'C — LES_AUTOP=1; idade >=10':dados['DEZ_MAIS'],
    'D — LES_AUTOP=1 e REL_PROPRI=1; idade >=10':dados['DEZ_MAIS'] & dados['REL_STATUS'].eq(STATUS[0]),
}

resumo_criterios = []
sens_raca = []
sens_uf = []
base_raca = dados['RACA'].value_counts().reindex(RACAS,fill_value=0)
base_uf22 = dados.loc[dados['ANO'].eq(2022)].groupby(['UF','RACA']).size()

for nome, mask in criterios.items():
    subset = dados.loc[mask]
    n = len(subset)
    n22 = int(subset['ANO'].eq(2022).sum())
    resumo_criterios.append({
        'Critério':nome,
        '2015–2024: notificações (n)':n,
        '2015–2024: excluídas em relação ao principal (n)':N-n,
        '2015–2024: redução (%)':round(100*(N-n)/N,2),
        '2022: notificações (n)':n22,
        '2022: excluídas em relação ao principal (n)':N2022-n22,
        '2022: redução (%)':round(100*(N2022-n22)/N2022,2),
    })
    counts = subset['RACA'].value_counts().reindex(RACAS,fill_value=0)
    for raca in RACAS:
        base = int(base_raca[raca])
        atual = int(counts[raca])
        sens_raca.append({
            'Critério':nome,'Grupo racial':raca,
            'Notificações 2015–2024 (n)':atual,
            'Diferença em relação ao principal (n)':atual-base,
            'Redução dentro do grupo (%)':round(100*(base-atual)/base,2) if base else np.nan,
            'Participação entre notificações do critério (%)':round(100*atual/n,2) if n else np.nan,
        })
    counts_uf = subset.loc[subset['ANO'].eq(2022)].groupby(['UF','RACA']).size()
    for uf in UF_ORDENADAS:
        for raca in ['Brancos','Negros','Indígenas']:
            base = int(base_uf22.get((uf,raca),0))
            atual = int(counts_uf.get((uf,raca),0))
            sens_uf.append({
                'UF':uf,'Grupo racial':raca,'Critério':nome,
                '2022: notificações (n)':atual,
                '2022: redução em relação ao principal (n)':base-atual,
                '2022: redução dentro do grupo (%)':round(100*(base-atual)/base,2) if base else np.nan,
            })

resumo_criterios = pd.DataFrame(resumo_criterios)
sens_raca = pd.DataFrame(sens_raca)
sens_uf = pd.DataFrame(sens_uf)

# 5. Conferências e rastreabilidade.
validacoes = pd.DataFrame([
    ['Registros lidos do Parquet',registros_lidos,'Esperado anteriormente: 3.881.759'],
    ['Notificações elegíveis — critério A',N,'Esperado anteriormente: 334.638'],
    ['Notificações em 2022 — critério A',N2022,'Esperado anteriormente: 41.710'],
    ['REL_PROPRI=1',int(dados['REL_STATUS'].eq(STATUS[0]).sum()),'Concordância explícita'],
    ['REL_PROPRI=2',int(dados['REL_STATUS'].eq(STATUS[1]).sum()),'Anteriormente: 10.610'],
    ['REL_PROPRI=9',int(dados['REL_STATUS'].eq(STATUS[2]).sum()),'Ignorado'],
    ['REL_PROPRI vazio',int(dados['REL_STATUS'].eq(STATUS[3]).sum()),'Campo em branco'],
    ['REL_PROPRI outro código',int(dados['REL_STATUS'].eq(STATUS[4]).sum()),'Fora das categorias oficiais'],
    ['Menores de 10 anos com idade válida',Nmenor,'Anteriormente: 5.131'],
    ['Idade igual ou superior a 10 anos',N10mais,'Elegível à sensibilidade ≥10'],
    ['Idade inválida ou não decodificável',Nidade_inv,'Preservada no principal'],
    ['Sem UF de residência válida',int(dados['UF'].eq('SEM_UF').sum()),'Preservada no conjunto nacional'],
    ['Outros vínculos REL_* examinados',len(rel_adicionais),'Apenas marcação agregada, sem vincular causalmente'],
    ['VIOL_OUTR disponível',int('VIOL_OUTR' in opcionais),'1=sim; campo auxiliar'],
    ['VIOL_ESPEC disponível',int('VIOL_ESPEC' in opcionais),'Somente presença/ausência, texto não exportado'],
], columns=['Verificação','Valor','Interpretação / referência'])

assert int(por_ano['Total de notificações'].sum()) == N
assert int(por_raca['Total de notificações'].sum()) == N
assert int(ufs22['Total de notificações'].sum()) == N2022
assert int(menores_por_idade['Total'].sum()) == Nmenor
assert int(menores_por_ano['Total'].sum()) == Nmenor
assert sum(int(dados['REL_STATUS'].eq(st).sum()) for st in STATUS) == N
assert int(resumo_criterios.iloc[0]['2015–2024: notificações (n)']) == N

if N != 334638 or N2022 != 41710:
    print('⚠ ATENÇÃO: totais divergem da Tabela 1 anterior. Verifique antes de comparar.')

leia = pd.DataFrame([
    ['OBJETIVO','Auditoria exploratória dos critérios de seleção, não produto final de artigo.'],
    ['Concordancia_ano','Número e porcentagem de REL_PROPRI=1,2,9,vazio/outros, segundo ano. As porcentagens usam todas as notificações do ano.'],
    ['Concordancia_raca','A mesma concordância, separadamente por grupo racial; amarelos e não classificados são preservados.'],
    ['Concordancia_UF22','Concordância por UF de residência apenas em 2022. SEM_UF é categoria de qualidade, não uma UF.'],
    ['Menores_10_idade','Registros de 0 a 9 anos, por idade completa e raça/cor. NÃO se presume erro de notificação.'],
    ['Menores_10_ano','Registros com idade válida menor de 10 anos, por ano de notificação e raça/cor.'],
    ['Sinais_ficha','Proporção de registros com outros vínculos assinalados, VIOL_OUTR e presença de VIOL_ESPEC. Não inclui texto livre.'],
    ['Resumo_criterios','Contrasta A (principal), B (REL_PROPRI=1), C (10+) e D (ambos). NÃO escolhe um deles.'],
    ['Sensibilidade_raca','Redução de notificações por grupo racial conforme critérios alternativos.'],
    ['Sensibilidade_UF22','Impacto de B, C e D nos numeradores de 2022 por UF e grupo racial, mesmo quando contagem chega a zero.'],
    ['Controles','Quantidades-chave para conferência, incluindo totais da Tabela 1 v03.'],
    ['Interpretação','LES_AUTOP é classificação direta da lesão; REL_PROPRI representa o provável autor assinalado. Discordância é sinal de qualidade a investigar.'],
    ['Regra metodológica','Não excluir REL_PROPRI=2/vazio nem crianças de 0–9 anos sem fundamentação e análise de sensibilidade.'],
    ['Fontes (manual)','https://bvsms.saude.gov.br/bvs/publicacoes/viva_instrutivo_violencia_interpessoal_autoprovocada_2ed.pdf'],
    ['Fontes (dicionário)','https://portalsinan.saude.gov.br/images/documentos/Agravos/via/DIC_DADOS_NET_Violencias_v5.pdf'],
],columns=['Aba / assunto','Como interpretar'])

abas = {
    'LEIA_PRIMEIRO':leia,
    'Concordancia_ano':por_ano,
    'Concordancia_raca':por_raca,
    'Concordancia_UF22':ufs22,
    'Menores_10_idade':menores_por_idade,
    'Menores_10_ano':menores_por_ano,
    'Sinais_ficha':aux,
    'Resumo_criterios':resumo_criterios,
    'Sensibilidade_raca':sens_raca,
    'Sensibilidade_UF22':sens_uf,
    'Controles':validacoes,
}

# Exportação: preservar números como células numéricas, sem inserir
# separadores de milhar como strings. O Excel aplica idioma/localidade
# no momento da exibição. Ao longo do artigo, produzir BR e US.
with pd.ExcelWriter(ARQUIVO_XLSX,engine='xlsxwriter') as writer:
    livro = writer.book
    fmt_cab = livro.add_format({'bold':True,'bg_color':'#DCEAEF','font_color':'#133044',
                                 'border':0,'text_wrap':True,'valign':'vcenter'})
    fmt_pct = livro.add_format({'num_format':'0.00','align':'right'})
    fmt_int = livro.add_format({'num_format':'#,##0','align':'right'})
    fmt_texto = livro.add_format({'text_wrap':True,'valign':'top'})
    for nome, tab in abas.items():
        tab.to_excel(writer,sheet_name=nome,index=False)
        ws = writer.sheets[nome]
        ws.freeze_panes(1,1)
        ws.set_row(0,34,fmt_cab)
        ws.autofilter(0,0,len(tab),len(tab.columns)-1)
        ws.set_column(0,0,36,fmt_texto)
        for j,col in enumerate(tab.columns[1:],1):
            if nome=='LEIA_PRIMEIRO' and j==1:
                ws.set_column(j,j,100,fmt_texto)
            elif nome=='Controles' and j==2:
                ws.set_column(j,j,55,fmt_texto)
            elif nome.startswith('Sensibilidade') and j in [1,2]:
                ws.set_column(j,j,38,fmt_texto)
            elif pd.api.types.is_numeric_dtype(tab[col]):
                formato = fmt_pct if ('%' in str(col)) else fmt_int
                ws.set_column(j,j,21,formato)
            else:
                ws.set_column(j,j,27,fmt_texto)
        ws.set_landscape()
        ws.fit_to_pages(1,0)
        ws.set_footer('Auditoria SINAN 2015–2024 | &P / &N')

print('\n=== RESUMO PRINCIPAL ===')
print(f'Notificações: {N:,} | 2022: {N2022:,} | menores de 10: {Nmenor:,}')
print('\nCONCORDÂNCIA POR RAÇA/COR')
print(por_raca.to_string(index=False))
print('\nSENSIBILIDADE DE CRITÉRIOS')
print(resumo_criterios.to_string(index=False))
print('\nArquivo produzido:')
print(ARQUIVO_XLSX)
print('\nA análise é diagnóstica; não foram alterados critérios nem arquivos anteriores.')
