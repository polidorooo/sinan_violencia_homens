# -*- coding: utf-8 -*-
"""
SCRIPT 03B | TABELA 2 DEFINITIVA — GRANDES REGIÕES E BRASIL, 2022
Violência autoprovocada notificada entre pessoas registradas com sexo masculino.

ENTRADA (já produzida pelo Script 03; NÃO é necessário reler o Parquet):
  /content/RESULTADOS_ARTIGO/01_tabelas/03_taxas_violencia_autoprovocada_2022.xlsx

SAÍDAS:
  /content/RESULTADOS_ARTIGO/01_tabelas/03B_Tabela_2_regioes_p_2022.xlsx
  /content/RESULTADOS_ARTIGO/01_tabelas/03B_Tabela_2_regioes_BR.csv
  /content/RESULTADOS_ARTIGO/01_tabelas/03B_Tabela_2_regioes_US.csv

TAXAS: padronização etária direta, padrão = total de homens do Brasil, Censo 2022.
IC95%: gama Fay–Feuer. Região = SOMA de notificações e populações por faixa,
NUNCA média aritmética de taxas estaduais.

p PRINCIPAL: teste global condicional sob Poisson, estratificado pelas oito
faixas etárias. Dado o número total de notificações em cada faixa, distribui
as notificações entre os três grupos segundo suas populações, por simulação
multinomial. Estatística: maior contraste pareado absoluto entre taxas
padronizadas dividido por seu desvio-padrão condicional sob H0. Hipótese nula:
mesma taxa ESPECÍFICA POR IDADE nos três grupos raciais. Portanto, o p NÃO
é um teste exclusivamente da igualdade numérica das três taxas padronizadas.

Checagem secundária: regressão de Poisson com offset log(população), faixa
etária e raça/cor; p por razão de verossimilhanças, com diagnóstico de
sobredispersão e bondade de ajuste. A inferência pressupõe independência das
notificações, o que não pode ser garantido pelo SINAN. Ambos os valores de p
são exploratórios e não corrigem subnotificação ou registros repetidos.

A Tabela 2 contém SOMENTE os três estratos raciais e um p por região.
O total, as taxas brutas, as 27 UFs e os testes detalhados ficam em abas
separadas. Nenhum arquivo original é modificado.
"""
from __future__ import annotations

import importlib.util
import sys
import subprocess
for modulo, pacote in [('numpy','numpy'),('pandas','pandas'),('scipy','scipy'),
                       ('openpyxl','openpyxl'),('xlsxwriter','XlsxWriter'),
                       ('statsmodels','statsmodels')]:
    if importlib.util.find_spec(modulo) is None:
        print('Instalando dependência ausente:', pacote)
        subprocess.check_call([sys.executable,'-m','pip','install','-q',pacote])

from datetime import datetime
from pathlib import Path
import platform
import warnings
import math
import numpy as np
import pandas as pd
import scipy
from scipy.stats import chi2, gamma
import statsmodels.api as sm
import statsmodels.formula.api as smf

# --------------- CONFIGURAÇÃO ---------------
ROOT = Path('/content')
ARQUIVO_ORIGEM = ROOT / 'RESULTADOS_ARTIGO' / '01_tabelas' / '03_taxas_violencia_autoprovocada_2022.xlsx'
DIR_SAIDA = ROOT / 'RESULTADOS_ARTIGO' / '01_tabelas'
SAIDA_EXCEL = DIR_SAIDA / '03B_Tabela_2_regioes_p_2022.xlsx'
SAIDA_CSV_BR = DIR_SAIDA / '03B_Tabela_2_regioes_BR.csv'
SAIDA_CSV_US = DIR_SAIDA / '03B_Tabela_2_regioes_US.csv'

ESCALA = 100_000
ALFA = 0.05
SIMULACOES = 49_999  # Menor p resolvível: 1/50.000
SEMENTE = 20261104
GRUPOS = ['Brancos', 'Negros', 'Indígenas']
TODOS_GRUPOS = ['Total'] + GRUPOS
FAIXAS = ['0–9','10–14','15–19','20–24','25–29','30–44','45–59','60+']
REGIOES_UFS = {
    'Norte': ['RO','AC','AM','RR','PA','AP','TO'],
    'Nordeste': ['MA','PI','CE','RN','PB','PE','AL','SE','BA'],
    'Sudeste': ['MG','ES','RJ','SP'],
    'Sul': ['PR','SC','RS'],
    'Centro-Oeste': ['MS','MT','GO','DF'],
}
ORDEM = list(REGIOES_UFS) + ['Brasil']
UFS = [u for xs in REGIOES_UFS.values() for u in xs]
COL_N = 'Notificações (n)'
COL_P = 'População masculina (n)'


def interromper(mensagem):
    raise ValueError('VALIDAÇÃO INTERROMPIDA — ' + mensagem)


def verificar_inteiros(df, colunas):
    for col in colunas:
        z = pd.to_numeric(df[col], errors='coerce')
        if z.isna().any() or (~np.isfinite(z)).any() or (z < 0).any() or (z % 1 != 0).any():
            interromper(f'Contagens/populações inválidas em {col}')
        df[col] = z.astype('int64')


def ler_arquivo():
    print('ETAPA 1/5 — Lendo e validando as saídas do Script 03')
    if not ARQUIVO_ORIGEM.exists():
        raise FileNotFoundError('Arquivo do Script 03 ausente: '+str(ARQUIVO_ORIGEM)+
                                '\nExecute antes o Script 03 original, sem alterar seu nome de saída.')
    with pd.ExcelFile(ARQUIVO_ORIGEM, engine='openpyxl') as xl:
        requeridas = {'Taxas_por_Idade','Taxas_2022_Detalhe',
                      'Pesos_Padrao_2022','Tabela_2_Publicacao','Sensibilidade_A_B_C_D'}
        if not requeridas.issubset(xl.sheet_names):
            interromper('Abas ausentes: '+str(sorted(requeridas-set(xl.sheet_names))))
        et = pd.read_excel(xl, sheet_name='Taxas_por_Idade')
        dt = pd.read_excel(xl, sheet_name='Taxas_2022_Detalhe')
        pes = pd.read_excel(xl, sheet_name='Pesos_Padrao_2022')
        suple = pd.read_excel(xl, sheet_name='Tabela_2_Publicacao')
        sens = pd.read_excel(xl, sheet_name='Sensibilidade_A_B_C_D')

    obrig_et = {'UF','Grupo racial','Faixa etária',COL_N,COL_P}
    obrig_dt = {'UF','RACA','Notificações (n)','Idade inválida (n)',
                'Notificações com idade válida (n)','População masculina (n)',
                'Taxa padronizada/100 mil'}
    if not obrig_et.issubset(et.columns) or not obrig_dt.issubset(dt.columns):
        interromper('Cabeçalhos do Script 03 não correspondem ao formato esperado')
    if len(et)!=28*4*8 or len(dt)!=28*4:
        interromper(f'Número inesperado de linhas: etárias={len(et)}, detalhe={len(dt)}')
    if et[['UF','Grupo racial','Faixa etária']].duplicated().any():
        interromper('Duplicatas UF × raça × idade')
    if set(et['UF'])!=set(UFS+['BR']) or set(et['Grupo racial'])!=set(TODOS_GRUPOS) or set(et['Faixa etária'])!=set(FAIXAS):
        interromper('UF, raça ou faixas não correspondem aos 28 × 4 × 8 esperados')
    verificar_inteiros(et,[COL_N,COL_P])
    verificar_inteiros(dt,['Notificações (n)','Idade inválida (n)',
                         'Notificações com idade válida (n)','População masculina (n)'])
    grp = et.groupby(['UF','Grupo racial'],as_index=False)[[COL_N,COL_P]].sum()
    grp = grp.rename(columns={COL_N:'N_FAIXAS',COL_P:'POP_FAIXAS'})
    combinado = dt.merge(grp,left_on=['UF','RACA'],right_on=['UF','Grupo racial'],how='left',validate='one_to_one')
    if combinado['N_FAIXAS'].isna().any():
        interromper('Faltam categorias de denominador/idade')
    if not (combinado['N_FAIXAS']==combinado['Notificações com idade válida (n)']).all():
        interromper('Contagem por idade não coincide com detalhe original')
    if not (combinado['POP_FAIXAS']==combinado['População masculina (n)']).all():
        interromper('Denominador por idade difere do total original')
    if not (combinado['Notificações (n)'] == combinado['N_FAIXAS']+combinado['Idade inválida (n)']).all():
        interromper('Contagem total não corresponde a idade válida + inválida')
    br = dt.set_index(['UF','RACA'])
    esperado = {('BR','Total'):41710,('BR','Brancos'):17168,
                ('BR','Negros'):20381,('BR','Indígenas'):317}
    for k,n in esperado.items():
        if int(br.loc[k,'Notificações (n)'])!=n:
            interromper(f'Controle nacional de notificações não coincide: {k}')
    if int(br.loc[('BR','Total'),'Idade inválida (n)'])!=124:
        interromper('Idades inválidas no total nacional diferentes de 124')
    soma_ufs = dt.loc[(dt.UF!='BR')&(dt.RACA=='Total'),'Notificações (n)'].sum()
    if int(soma_ufs)!=41707:
        interromper(f'Soma das 27 UFs {soma_ufs}: esperados 41.707 (3 sem UF)')
    if set(pes['Faixa etária'])!=set(FAIXAS):
        interromper('Pesos da população padrão em faixas incompatíveis')
    if 'Peso (todas as idades)' not in pes.columns:
        interromper('Coluna do padrão nacional ausente')
    p = pes.set_index('Faixa etária').loc[FAIXAS]
    pesos = p['Peso (todas as idades)'].to_numpy(dtype=float)
    if not np.isclose(sum(pesos),1.0,atol=1e-10) or (pesos<=0).any():
        interromper('Pesos etários inválidos')
    if int(p['População masculina Brasil 2022'].sum())!=98532431:
        interromper('População nacional padrão não é 98.532.431')
    if int(br.loc[('BR','Total'),'População masculina (n)'])!=98532431:
        interromper('Denominador masculino nacional não coincide')
    if et[COL_P].eq(0).any():
        interromper('Encontrado denominador zero; não proceder por imputação')
    print('  Origem validada: 896 células etárias; 112 estimativas territoriais; 27 UFs + Brasil.')
    print('  Brasil: 41.710 notificações (inclui 3 sem UF); indígenas: 317.')
    return et,dt,pesos,suple,sens


def agregar_por_regiao(et,dt):
    print('\nETAPA 2/5 — Agregação das contagens e populações por grandes regiões')
    grupos=[]
    detalhes=[]
    for regiao in ORDEM:
        # Para o Brasil, usar a linha BR original: preserva os 3 registros sem UF.
        if regiao=='Brasil':
            x = et.loc[et.UF=='BR'].copy()
            y = dt.loc[dt.UF=='BR'].copy()
        else:
            x = et.loc[et.UF.isin(REGIOES_UFS[regiao])].copy()
            y = dt.loc[dt.UF.isin(REGIOES_UFS[regiao])].copy()
        agrupado = x.groupby(['Grupo racial','Faixa etária'],as_index=False,observed=True)[[COL_N,COL_P]].sum()
        completo = pd.MultiIndex.from_product([TODOS_GRUPOS,FAIXAS],names=['Grupo racial','Faixa etária']).to_frame(index=False)
        agrupado = completo.merge(agrupado,on=['Grupo racial','Faixa etária'],how='left',validate='one_to_one')
        if agrupado[[COL_N,COL_P]].isna().any().any():
            interromper('Faixa faltante em '+regiao)
        agrupado['Região'] = regiao
        grupos.append(agrupado[['Região','Grupo racial','Faixa etária',COL_N,COL_P]])
        resumo = y.groupby('RACA',as_index=False)[['Notificações (n)','Idade inválida (n)']].sum()
        resumo['Região']=regiao
        detalhes.append(resumo)
    et_reg=pd.concat(grupos,ignore_index=True)
    n_reg=pd.concat(detalhes,ignore_index=True).rename(columns={'RACA':'Grupo racial'})
    if len(et_reg)!=6*4*8 or len(n_reg)!=6*4:
        interromper('Agregação regional inesperada')
    soma = et_reg.groupby(['Região','Grupo racial'],as_index=False)[COL_N].sum().rename(columns={COL_N:'N_FAIXAS'})
    conferir = n_reg.merge(soma,on=['Região','Grupo racial'],validate='one_to_one')
    if not (conferir['Notificações (n)']==conferir['N_FAIXAS']+conferir['Idade inválida (n)']).all():
        interromper('Perda de contagens na agregação regional')
    populacao = et_reg.groupby(['Região','Grupo racial'])[COL_P].sum()
    if int(populacao.loc[('Brasil','Indígenas')])!=611068:
        interromper('População masculina indígena do Brasil não coincide com Censo')
    # Conservação dos totais estaduais e nacionais; Brasil pode conter SEM_UF.
    for rac in TODOS_GRUPOS:
        n_regioes=int(n_reg.loc[(n_reg.Região!='Brasil')&(n_reg['Grupo racial']==rac),'Notificações (n)'].sum())
        n_ufs=int(dt.loc[(dt.UF!='BR')&(dt.RACA==rac),'Notificações (n)'].sum())
        if n_regioes!=n_ufs:
            interromper('Agregação não reproduz soma das UFs: '+rac)
    print('  Grupos territoriais: 5 regiões + Brasil; total regional de notificações = 41.707.')
    return et_reg,n_reg


def gamma_fay_feuer(n,p,w):
    """Fay–Feuer, IC95% gama conservador da taxa padronizada diretamente."""
    n=np.asarray(n,dtype=float);p=np.asarray(p,dtype=float);w=np.asarray(w,dtype=float)
    if not (len(n)==len(p)==len(w)==8) or (p<=0).any() or (n<0).any():
        interromper('Populações/contagens inválidas para padronização')
    if not np.isclose(w.sum(),1):
        interromper('Pesos não somam 1')
    a=w/p
    y=float(np.dot(a,n))
    v=float(np.dot(a*a,n))
    m=float(a.max())
    li=float(gamma.ppf(ALFA/2,a=y*y/v,scale=v/y)) if v>0 else 0.0
    y2=y+m;v2=v+m*m
    ls=float(gamma.ppf(1-ALFA/2,a=y2*y2/v2,scale=v2/y2))
    return y*ESCALA,li*ESCALA,ls*ESCALA,v*ESCALA*ESCALA


def estimar_regioes(et_reg,n_reg,pesos,dt):
    print('\nETAPA 3/5 — Recalculando taxas regionais e IC95%')
    saida=[]
    for reg in ORDEM:
        for raca in TODOS_GRUPOS:
            s = et_reg.loc[(et_reg.Região==reg)&(et_reg['Grupo racial']==raca)].set_index('Faixa etária').loc[FAIXAS]
            n = int(s[COL_N].sum());pop = int(s[COL_P].sum())
            res = n_reg.loc[(n_reg.Região==reg)&(n_reg['Grupo racial']==raca)].iloc[0]
            total = int(res['Notificações (n)']);inv=int(res['Idade inválida (n)'])
            if total!=n+inv:
                interromper('Total incompatível para '+reg+' / '+raca)
            pad,li,ls,var=gamma_fay_feuer(s[COL_N],s[COL_P],pesos)
            bruto = total/pop*ESCALA
            saida.append({'Região':reg,'Grupo racial':raca,'Notificações (n)':total,
                          'Idade inválida (n)':inv,'Numerador da padronização (n)':n,
                          'População masculina (n)':pop,'Taxa bruta/100 mil':bruto,
                          'Taxa padronizada/100 mil':pad,
                          'IC95% LI':li,'IC95% LS':ls,
                          'Variância da taxa padronizada':var,
                          'Estado do cálculo':'OK' if pop>0 else 'NE'})
    result=pd.DataFrame(saida)
    nacional=result.set_index(['Região','Grupo racial'])
    referencia=dt.set_index(['UF','RACA'])
    for raca in TODOS_GRUPOS:
        obtido=float(nacional.loc[('Brasil',raca),'Taxa padronizada/100 mil'])
        original=float(referencia.loc[('BR',raca),'Taxa padronizada/100 mil'])
        if not np.isclose(obtido,original,atol=1e-9,rtol=1e-10):
            interromper(f'A taxa do Brasil divergiu do Script 03 para {raca}: {obtido} vs {original}')
    previas={('Norte','Indígenas'):52.3,('Nordeste','Indígenas'):19.9,
             ('Sudeste','Indígenas'):97.7,('Sul','Brancos'):65.7,
             ('Centro-Oeste','Negros'):49.8}
    for k,v in previas.items():
        obtido=float(nacional.loc[k,'Taxa padronizada/100 mil'])
        if abs(obtido-v)>.15:
            interromper(f'Prévia regional não coincide com {k}: {obtido} vs {v}')
    print('  Taxas regionais conferidas com prévia e total nacional Script 03.')
    return result


def teste_condicional_poisson(matriz_n,matriz_p,pesos,simulacoes,seed):
    """Teste condicional sob Poisson, com Monte Carlo e contraste max-|Z|.

    H0: para cada faixa, as 3 raças têm a MESMA taxa específica por idade.
    Condicional a M_a = soma dos casos nas 3 raças, as contagens dos grupos
    seguem Multinomial(M_a; P_ar / soma_r P_ar).

    Estatística: máximo, entre os três pares raciais, de |D_rs|/sqrt(Var0(D_rs)),
    onde D_rs é a diferença entre taxas diretamente padronizadas por idade.
    Condicionar por idade preserva os totais das faixas e elimina as taxas
    etárias desconhecidas da distribuição nula.
    """
    n=np.asarray(matriz_n,dtype='int64')
    pop=np.asarray(matriz_p,dtype=float)
    pesos=np.asarray(pesos,dtype=float)
    if n.shape!=(8,3) or pop.shape!=(8,3) or (pop<=0).any():
        interromper('Formato incompatível no teste condicional')
    m=n.sum(axis=1)
    prob=pop/pop.sum(axis=1,keepdims=True)
    coef=pesos[:,None]/pop * ESCALA
    t_ob=(n*coef).sum(axis=0)
    pares=[(0,1),(0,2),(1,2)]
    # Sob H0, variância condicional exata da diferença de taxas padronizadas:
    # Var(D_rs|M) = sum_a w_a² M_a (q_ar/P_ar² + q_as/P_as²) × 100000².
    variancias=np.array([np.sum((pesos**2)*m*(prob[:,i]/pop[:,i]**2+
                                             prob[:,j]/pop[:,j]**2))*ESCALA**2
                         for i,j in pares])
    if (variancias<=0).any() or (~np.isfinite(variancias)).any():
        interromper('Variância condicional zero/indefinida entre grupos')
    diff_obs=np.array([t_ob[i]-t_ob[j] for i,j in pares])
    estat_obs=float(np.max(np.abs(diff_obs)/np.sqrt(variancias)))
    rng=np.random.default_rng(seed)
    sim_taxas=np.zeros((simulacoes,3),dtype=float)
    for faixa in range(8):
        if m[faixa]>0:
            sim_n=rng.multinomial(int(m[faixa]),prob[faixa],size=simulacoes)
            sim_taxas += sim_n*coef[faixa]
    diferencas=np.column_stack([sim_taxas[:,i]-sim_taxas[:,j] for i,j in pares])
    estat_sim=np.max(np.abs(diferencas)/np.sqrt(variancias),axis=1)
    extremos=int(np.count_nonzero(estat_sim>=estat_obs-1e-12))
    p=(extremos+1)/(simulacoes+1)
    return {'MC estatística max |Z|':estat_obs,'MC extremos':extremos,
            'p condicional Monte Carlo':float(p),
            'MC simulações':simulacoes,'MC seed':seed,
            'MC menor p possível':1/(simulacoes+1),
            'MC pares avaliados':'Brancos–Negros | Brancos–Indígenas | Negros–Indígenas'}


def diagnostico_poisson(matriz_n,matriz_p):
    """GLM log-linear com 8 faixas e 3 raças; comparação LR age-only vs age+raça."""
    linhas=[]
    for i,idade in enumerate(FAIXAS):
        for j,raca in enumerate(GRUPOS):
            linhas.append({'idade':idade,'raca':raca,
                           'notificacoes':int(matriz_n[i,j]),
                           'populacao':int(matriz_p[i,j])})
    dados=pd.DataFrame(linhas)
    dados['idade']=pd.Categorical(dados.idade,categories=FAIXAS,ordered=True)
    dados['raca']=pd.Categorical(dados.raca,categories=GRUPOS,ordered=True)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        m0=smf.glm('notificacoes ~ C(idade)',data=dados,
                   family=sm.families.Poisson(),offset=np.log(dados.populacao)).fit(maxiter=200,disp=0)
        m1=smf.glm('notificacoes ~ C(idade) + C(raca)',data=dados,
                   family=sm.families.Poisson(),offset=np.log(dados.populacao)).fit(maxiter=200,disp=0)
    lr=max(0.0,2.0*(m1.llf-m0.llf))
    gl=int(m1.df_model-m0.df_model)
    p_lr=float(chi2.sf(lr,gl))
    phi=float(m1.pearson_chi2/m1.df_resid) if m1.df_resid>0 else np.nan
    gof=float(chi2.sf(m1.deviance,m1.df_resid)) if m1.df_resid>0 else np.nan
    if any(not t.converged for t in [m0,m1]):
        interrupter='Convergência insuficiente do GLM Poisson'; interromper(interrupter)
    return {'p regressão Poisson (LR)':p_lr,'LR qui-quadrado':lr,'GL LR':gl,
            'Pearson dispersão φ':phi,'Deviance':float(m1.deviance),
            'GL residuais':int(m1.df_resid),'p bondade de ajuste':gof,
            'Avisos de ajuste':'; '.join(str(z.message) for z in w)[:500],
            'Diagnóstico do GLM':('Sobredispersão ou falta de ajuste: interpretar p de LR com cautela'
                                  if phi>1.5 or gof<0.05 else 'Sem alerta pelos limiares de diagnóstico')}


def testar_regioes(et_reg,pesos):
    print('\nETAPA 4/5 — Teste global por região e diagnósticos do GLM Poisson')
    testes=[]
    for k,reg in enumerate(ORDEM):
        rec=et_reg.loc[(et_reg.Região==reg)&et_reg['Grupo racial'].isin(GRUPOS)]
        n=np.array([[int(rec.loc[(rec['Grupo racial']==g)&(rec['Faixa etária']==idade),COL_N].iloc[0])
                     for g in GRUPOS] for idade in FAIXAS],dtype='int64')
        pop=np.array([[int(rec.loc[(rec['Grupo racial']==g)&(rec['Faixa etária']==idade),COL_P].iloc[0])
                       for g in GRUPOS] for idade in FAIXAS],dtype='int64')
        cond=teste_condicional_poisson(n,pop,pesos,SIMULACOES,SEMENTE+k)
        gl=diagnostico_poisson(n,pop)
        testes.append({'Região':reg,'N brancos':int(n[:,0].sum()),
                       'N negros':int(n[:,1].sum()),'N indígenas':int(n[:,2].sum()),
                       **cond,**gl})
        print(f"  {reg:13s} p condicional={cond['p condicional Monte Carlo']:.5g}  "
              f"p GLM={gl['p regressão Poisson (LR)']:.4g}  dispersão={gl['Pearson dispersão φ']:.2f}")
    return pd.DataFrame(testes)


def formatar_pt(numero,casas=1):
    return f'{float(numero):,.{casas}f}'.replace(',','§').replace('.',',').replace('§','.')


def formatar_us(numero,casas=1):
    return f'{float(numero):,.{casas}f}'


def formatar_p(p,locale='BR'):
    if not np.isfinite(p):return 'NE'
    if p<.001:return 'p < 0,001' if locale=='BR' else 'p < 0.001'
    return ('p = '+formatar_pt(p,3)) if locale=='BR' else ('p = '+formatar_us(p,3))


def formatar_celula(n,taxa,li,ls,locale='BR'):
    fmt=formatar_pt if locale=='BR' else formatar_us
    return f'{fmt(n,0)}; {fmt(taxa,1)} ({fmt(li,1)}–{fmt(ls,1)})'


def tabela_principal(taxas,testes,locale='BR'):
    """Publicação: N; taxa padronizada (IC95%) por raça, p global por região."""
    linhas=[]
    for reg in ORDEM:
        dados=taxas.loc[taxas.Região==reg].set_index('Grupo racial')
        item={'Região':reg}
        for g in GRUPOS:
            x=dados.loc[g]
            item[g+' — n; taxa (IC95%)']=formatar_celula(
                x['Notificações (n)'],x['Taxa padronizada/100 mil'],
                x['IC95% LI'],x['IC95% LS'],locale)
        p=float(testes.loc[testes.Região==reg,'p condicional Monte Carlo'].iloc[0])
        item['Valor de p']=formatar_p(p,locale)
        linhas.append(item)
    return pd.DataFrame(linhas)


def validar_produtos(taxas,testes,tabela,et_reg,dt):
    if len(taxas)!=24 or len(testes)!=6 or len(tabela)!=6 or len(et_reg)!=192:
        interromper('Dimensões da saída são inesperadas')
    if not ((taxas['IC95% LI']<=taxas['Taxa padronizada/100 mil']) &
            (taxas['Taxa padronizada/100 mil']<=taxas['IC95% LS'])).all():
        interromper('Intervalo de confiança não inclui a taxa estimada')
    if not testes['p condicional Monte Carlo'].between(0,1).all():
        interromper('p fora de [0,1]')
    if not (taxas['Notificações (n)']>=taxas['Numerador da padronização (n)']).all():
        interromper('Numeradores de padronização excedem o total')
    # Totais raciais não precisam somar ao total de homens: amarelos e ignorados estão fora.
    chk=taxas.pivot(index='Região',columns='Grupo racial',values='Notificações (n)')
    if not (chk[GRUPOS].sum(axis=1)<=chk['Total']).all():
        interromper('Soma racial ultrapassa o total de notificações')
    if int(chk.loc['Brasil','Total'])!=41710 or int(chk.loc['Brasil','Indígenas'])!=317:
        interromper('Total da Tabela 2 não corresponde à auditoria')
    print('  Conferências finais concluídas: totais, taxas, IC95% e p.')


def exportar(tabela_br,tabela_us,taxas,testes,et_reg,suple,sens):
    print('\nETAPA 5/5 — Exportando Excel e CSV (BR/US)')
    DIR_SAIDA.mkdir(parents=True,exist_ok=True)
    nota=(
        'Tabela 2 — Taxas padronizadas por idade de notificações de violência autoprovocada '
        'por 100 mil homens, segundo raça/cor e grandes regiões. Brasil, 2022.'
    )
    notes=[
       ['Produto principal',nota],
       ['Unidade de análise','Notificação SINAN de pessoa com sexo M e LES_AUTOP=1; não significa homem cis identificado.'],
       ['Leitura da célula','n de notificações; taxa padronizada por 100 mil (IC95%).'],
       ['Denominador','Homens residentes: IBGE Censo Demográfico 2022, tabela SIDRA 9606; sexo masculino e cor ou raça informada.'],
       ['Padronização','Direta pelas oito faixas etárias, padrão = todos os homens do Brasil, independentemente de raça/cor.'],
       ['IC95%','Gama de Fay–Feuer (1997), calculado sobre contagens e populações agregadas por faixa; NÃO média de ICs estaduais.'],
       ['p PRINCIPAL','Teste condicional sob Poisson com simulação multinomial estratificada por idade. Uma comparação global entre brancos, negros e indígenas por região.'],
       ['H0 do p','Taxas específicas por idade iguais nos três grupos raciais dentro de cada região; NÃO apenas igualdade numérica das taxas padronizadas.'],
       ['Estatística MC','Máximo dos três contrastes pareados de taxas padronizadas, em módulo, divididos por seus desvios-padrão condicionais.'],
       ['Monte Carlo',f'{SIMULACOES} simulações, sementes {SEMENTE} a {SEMENTE+5}, p=(1+extremos)/(1+simulações).'],
       ['Checagem GLM','Poisson log-linear, offset log(população), efeitos de faixa etária e raça; LR com 2 GL, com diagnóstico de dispersão e bondade de ajuste.'],
       ['Cautela inferencial','As notificações podem se repetir por pessoa; independência Poisson pode falhar. p exploratório, sem causalidade.'],
       ['Taxa versus risco','Taxas de notificações, não incidência real de lesões autoprovocadas; subnotificação e acesso a serviços podem diferir.'],
       ['Raça/cor negra','Pretos e pardos agregados em negros; indígenas definidos pelo quesito cor/raça, não pertencimento ampliado.'],
       ['Regiões','Região construída pela soma de numeradores e denominadores das UFs em cada faixa etária, antes do ajuste.'],
       ['BR distinto da soma das UFs','Brasil inclui três registros sem UF de residência válida, que não integram qualquer região.'],
       ['Idade inválida','Numeradores com idade ignorada integram taxas brutas, mas não taxas padronizadas. Conferir aba detalhe.'],
       ['UF','As 27 taxas estaduais originais foram preservadas exclusivamente como material suplementar.'],
       ['Sensibilidade','Aba de sensibilidade BR reutiliza dados nacionais A/B/C/D do Script 03; não se agregaram taxas estaduais de B/C/D.'],
       ['Mínimo p reportável',f'{1/(SIMULACOES+1):.6f}; saída editorial p < 0,001 quando aplicável.'],
       ['Fonte 1','SINAN — Parquet 2015–2024; selecionado 2022, critério A.'],
       ['Fonte 2','https://sidra.ibge.gov.br/tabela/9606'],
       ['Referência IC95%','Fay MP, Feuer EJ. Statistics in Medicine. 1997;16:791–801. DOI: 10.1002/(SICI)1097-0258(19970415)16:7<791::AID-SIM500>3.0.CO;2-#'],
       ['Data da execução',datetime.now().isoformat(timespec='seconds')],
       ['Versão Python',platform.python_version()],
       ['Versão pandas',pd.__version__],
       ['Versão SciPy',scipy.__version__],
       ['Versão statsmodels',sm.__version__],
    ]
    sens_br=sens.loc[sens.UF=='BR'].copy()
    # Exporta resultados numéricos integrais, sem arredondar no dado analítico.
    sheets={
        'LEIA_PRIMEIRO':pd.DataFrame(notes,columns=['Assunto','Nota metodológica / fonte']),
        'Tabela_2_Publicacao':tabela_br,
        'Tabela_2_US':tabela_us,
        'Taxas_Regioes_Detalhe':taxas,
        'Testes_e_Diagnosticos':testes,
        'Faixas_Regioes':et_reg,
        'Suplemento_UF_2022':suple,
        'Sensibilidade_Brasil':sens_br,
    }
    with pd.ExcelWriter(SAIDA_EXCEL,engine='xlsxwriter') as writer:
        livro=writer.book
        cab=livro.add_format({'bold':True,'font_color':'#FFFFFF','bg_color':'#18354B',
                              'text_wrap':True,'valign':'vcenter','font_name':'Aptos','font_size':10,
                              'bottom':1,'bottom_color':'#A6BBC6'})
        texto=livro.add_format({'font_name':'Aptos','font_size':10,'valign':'vcenter'})
        alternado=livro.add_format({'font_name':'Aptos','font_size':10,'valign':'vcenter',
                                   'bg_color':'#F1F6F8'})
        numero=livro.add_format({'num_format':'#,##0.0000','font_name':'Aptos','font_size':10})
        for sheet,df in sheets.items():
            df.to_excel(writer,sheet_name=sheet,index=False,startrow=1,header=False)
            ws=writer.sheets[sheet]
            ws.set_default_row(19)
            ws.set_row(0,42)
            ws.freeze_panes(1,1)
            ws.hide_gridlines(2)
            for i,c in enumerate(df.columns):
                ws.write(0,i,c,cab)
                if sheet=='LEIA_PRIMEIRO': w=30 if i==0 else 98
                elif sheet.startswith('Tabela_2'): w=18 if i==0 else (42 if i<len(df.columns)-1 else 18)
                elif sheet=='Testes_e_Diagnosticos': w=26 if i in (0,len(df.columns)-1) else 21
                else: w=29 if i==0 else (27 if len(c)>21 else 20)
                ws.set_column(i,i,w)
            ws.autofilter(0,0,len(df),len(df.columns)-1)
            if sheet.startswith('Tabela_2'):
                ws.set_landscape();ws.fit_to_pages(1,1)
                ws.set_paper(9)
                for row in range(1,len(df)+1):
                    ws.set_row(row,25)
            elif sheet=='LEIA_PRIMEIRO':
                for row in range(1,len(df)+1):ws.set_row(row,28)
            # Linhas em zebrado são suficientes; dados numéricos permanecem números reais.
            ws.conditional_format(1,0,len(df),len(df.columns)-1,
                {'type':'formula','criteria':'=MOD(ROW(),2)=0','format':alternado})
    tabela_br.to_csv(SAIDA_CSV_BR,index=False,sep=';',encoding='utf-8-sig')
    tabela_us.to_csv(SAIDA_CSV_US,index=False,sep=',',encoding='utf-8-sig')
    for path in [SAIDA_EXCEL,SAIDA_CSV_BR,SAIDA_CSV_US]:
        if not path.exists() or path.stat().st_size<=100:
            interromper('Falha na exportação de '+str(path))
    print('  Excel:',SAIDA_EXCEL)
    print('  CSV BR:',SAIDA_CSV_BR)
    print('  CSV US:',SAIDA_CSV_US)


def main():
    et,dt,pesos,suple,sens=ler_arquivo()
    et_reg,n_reg=agregar_por_regiao(et,dt)
    taxas=estimar_regioes(et_reg,n_reg,pesos,dt)
    testes=testar_regioes(et_reg,pesos)
    tabela_br=tabela_principal(taxas,testes,'BR')
    tabela_us=tabela_principal(taxas,testes,'US')
    validar_produtos(taxas,testes,tabela_br,et_reg,dt)
    exportar(tabela_br,tabela_us,taxas,testes,et_reg,suple,sens)
    print('\nTABELA 2 (versão brasileira):\n'+tabela_br.to_string(index=False))
    print('\nCONCLUÍDO. Não modificar os arquivos de origem nem usar médias de taxas estaduais.')


if __name__=='__main__':
    main()
