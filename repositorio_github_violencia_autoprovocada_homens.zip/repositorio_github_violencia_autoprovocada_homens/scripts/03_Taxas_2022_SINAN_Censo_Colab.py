# -*- coding: utf-8 -*-
"""
SCRIPT 03 | Taxas de notificações de violência autoprovocada entre homens
Brasil e 27 UF, 2022 | Critério A e sensibilidade B/C/D

Entradas (não são alteradas):
    /content/SINAN_VIOLENCIA_2015_2024.parquet
    /content/censo2022_homens_uf_raca_idade.csv
Saída:
    /content/RESULTADOS_ARTIGO/01_tabelas/03_taxas_violencia_autoprovocada_2022.xlsx

Nota conceitual: o numerador é NOTIFICAÇÕES; a taxa não mede incidência
verdadeira de autolesão ou de tentativa de suicídio nem pessoas únicas.
"""

from __future__ import annotations

import sys
import subprocess
import importlib.util

# O Script 02 exigiu XlsxWriter que não estava instalado. Este script usa
# openpyxl, instalando somente bibliotecas ausentes no ambiente do Colab.
for modulo, pacote in [('numpy','numpy'), ('pandas','pandas'), ('pyarrow','pyarrow'),
                       ('scipy','scipy'), ('openpyxl','openpyxl')]:
    if importlib.util.find_spec(modulo) is None:
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-q', pacote])

import re
import math
import platform
from pathlib import Path
from datetime import datetime
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import scipy
from scipy.stats import chi2, gamma, norm
from openpyxl import load_workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import CellIsRule

# CONFIGURAÇÕES: alterar somente se os arquivos estiverem em outro diretório.
BASE = Path('/content')
PARQUET = BASE / 'SINAN_VIOLENCIA_2015_2024.parquet'
CENSO = BASE / 'censo2022_homens_uf_raca_idade.csv'
DESTINO = BASE / 'RESULTADOS_ARTIGO' / '01_tabelas'
SAIDA = DESTINO / '03_taxas_violencia_autoprovocada_2022.xlsx'

ANO_ALVO = 2022
ALFA = 0.05
ESCALA = 100_000
FAIXAS = ['0–9', '10–14', '15–19', '20–24', '25–29', '30–44', '45–59', '60+']
RACAS = ['Total', 'Brancos', 'Negros', 'Indígenas']
CENARIOS = ['A', 'B', 'C', 'D']
UF_IBGE = {
    '11':'RO', '12':'AC', '13':'AM', '14':'RR', '15':'PA', '16':'AP', '17':'TO',
    '21':'MA', '22':'PI', '23':'CE', '24':'RN', '25':'PB', '26':'PE', '27':'AL',
    '28':'SE', '29':'BA', '31':'MG', '32':'ES', '33':'RJ', '35':'SP', '41':'PR',
    '42':'SC', '43':'RS', '50':'MS', '51':'MT', '52':'GO', '53':'DF'
}
UFS = [UF_IBGE[x] for x in UF_IBGE]
COLS_RACA_CENSO = {'Total':'TOTAL_HOMENS', 'Brancos':'BRANCOS',
                    'Negros':'NEGROS', 'Indígenas':'INDIGENAS'}
CONTROLES_ESPERADOS = {'parquet':3881759, '2015_2024_A':334638,
                       '2022_A':41710, '2022_B':39926,
                       '2022_C':40945, '2022_D':39404,
                       '2022_indigenas_A':317, '2022_sem_uf_A':3,
                       '2022_idade_invalida_A':124}


def falhar(mensagem):
    raise ValueError('AUDITORIA INTERROMPIDA — ' + mensagem)


def normalizar_codigo(serie):
    return (serie.astype('string').fillna('').str.strip()
                 .str.replace(r'^0+(?=\d)', '', regex=True))


def grupo_etario_de_limite_inferior(idade):
    if idade <= 9: return '0–9'
    if idade <= 14: return '10–14'
    if idade <= 19: return '15–19'
    if idade <= 24: return '20–24'
    if idade <= 29: return '25–29'
    if idade <= 44: return '30–44'
    if idade <= 59: return '45–59'
    return '60+'


def classificar_idade_censitaria(faixa):
    faixa = str(faixa).strip()
    if faixa == '100 anos ou mais': return '60+'
    m = re.fullmatch(r'(\d+) a (\d+) anos', faixa)
    if not m:
        falhar(f'Faixa etária desconhecida no Censo: {faixa!r}')
    minimo, maximo = map(int, m.groups())
    if maximo-minimo != 4 or minimo % 5 != 0:
        falhar(f'Faixa censitária inesperada: {faixa}')
    if grupo_etario_de_limite_inferior(minimo) != grupo_etario_de_limite_inferior(maximo):
        falhar(f'Faixa do Censo atravessa faixa analítica: {faixa}')
    return grupo_etario_de_limite_inferior(minimo)


def carregar_e_auditar_censo(caminho):
    print('ETAPA 1/4 — Auditando denominadores Censo 2022 (tabela SIDRA 9606)')
    if not caminho.exists():
        raise FileNotFoundError(f'Censo ausente: {caminho}')
    df = pd.read_csv(caminho, encoding='utf-8-sig', dtype={'COD_UF':str})
    req = {'UF','COD_UF','FAIXA_ETARIA','TOTAL_HOMENS','BRANCOS',
           'PRETOS','PARDOS','NEGROS','INDIGENAS','AMARELOS','RACA_IGNORADA_RESIDUAL'}
    if not req.issubset(df.columns):
        falhar(f'Colunas obrigatórias ausentes no CSV: {sorted(req-set(df.columns))}')
    if set(df['UF'].astype(str)) != set(UFS + ['BR']):
        falhar(f'O arquivo não contém exatamente Brasil + 27 UF: {set(df.UF)}')
    if len(df) != 616:
        falhar(f'Esperadas 616 linhas (28 territórios × 22 linhas etárias), encontradas {len(df)}')
    if df[['UF','FAIXA_ETARIA']].duplicated().any():
        falhar('UF × faixa etária duplicada no Censo')
    colunas_n = ['TOTAL_HOMENS','BRANCOS','PRETOS','PARDOS',
                 'NEGROS','INDIGENAS','AMARELOS','RACA_IGNORADA_RESIDUAL']
    for c in colunas_n:
        df[c] = pd.to_numeric(df[c], errors='coerce')
        if df[c].isna().any() or (df[c]<0).any() or (df[c]%1 != 0).any():
            falhar(f'Valor censitário ausente, negativo ou não inteiro em {c}')
        df[c] = df[c].astype('int64')
    if not (df['NEGROS']==df['PRETOS']+df['PARDOS']).all():
        falhar('NEGROS difere de PRETOS+PARDOS em pelo menos uma linha do Censo')
    soma_raca = df[['BRANCOS','NEGROS','INDIGENAS','AMARELOS','RACA_IGNORADA_RESIDUAL']].sum(axis=1)
    if not (soma_raca==df['TOTAL_HOMENS']).all():
        falhar('Soma de raças não coincide com TOTAL_HOMENS no CSV')
    codigos_esperados = dict(UF_IBGE)
    uf_para_codigo = {v:k for k,v in UF_IBGE.items()}
    if ((df.loc[df.UF!='BR','COD_UF'].astype(str)
             != df.loc[df.UF!='BR','UF'].map(uf_para_codigo)).any()
        or (df.loc[df.UF=='BR','COD_UF'].astype(str)!='BR').any()):
        falhar('Código e sigla de UF inconsistentes no CSV')
    totais = df.loc[df['FAIXA_ETARIA']=='TODAS_IDADES'].set_index('UF')
    quinquenais = df.loc[df['FAIXA_ETARIA']!='TODAS_IDADES'].copy()
    if quinquenais.groupby('UF').size().ne(21).any() or len(totais)!=28:
        falhar('O Censo deve ter 21 faixas quinquenais e um total por território')
    soma_grupos = quinquenais.groupby('UF')[colunas_n].sum()
    if not soma_grupos.sort_index().eq(totais[colunas_n].sort_index()).all().all():
        falhar('Soma das faixas quinquenais difere do total etário em alguma UF')
    if not totais.loc[UFS,colunas_n].sum().eq(totais.loc['BR',colunas_n]).all():
        falhar('Soma dos 27 estados difere da linha Brasil em alguma categoria')
    quinquenais['FAIXA'] = quinquenais.FAIXA_ETARIA.map(classificar_idade_censitaria)
    agg = (quinquenais.groupby(['UF','FAIXA'],as_index=False)[colunas_n]
           .sum())
    if len(agg)!=28*8:
        falhar('Falha ao formar 28 × 8 faixas de idade do Censo')
    if not agg.groupby('UF')[colunas_n].sum().sort_index().eq(totais[colunas_n].sort_index()).all().all():
        falhar('A harmonização de oito faixas não reproduziu os totais censitários')
    longos = []
    for r, coluna in COLS_RACA_CENSO.items():
        sub = agg[['UF','FAIXA',coluna]].copy().rename(columns={coluna:'POPULACAO'})
        sub['RACA'] = r
        longos.append(sub)
    denominadores = pd.concat(longos,ignore_index=True)
    denominadores['FAIXA'] = pd.Categorical(denominadores.FAIXA, categories=FAIXAS, ordered=True)
    denominadores = denominadores.sort_values(['UF','RACA','FAIXA']).reset_index(drop=True)
    # Não permitir população zero em nenhuma das oito faixas: se houver, a taxa
    # padronizada direta não pode ser produzida para o grupo/território.
    zeros = denominadores[denominadores.POPULACAO==0]
    print(f'Censo: {len(df)} linhas; 27 UFs + Brasil; faixas harmonizadas: 8.')
    if len(zeros):
        print(f'ALERTA: {len(zeros)} denominadores idade × raça × UF são zero; estimativas serão não calculáveis.')
    pop_br = totais.loc['BR','TOTAL_HOMENS']
    if int(pop_br)!=98532431:
        falhar(f'Total masculino do Censo diverge do CSV previamente auditado: {int(pop_br):,}')
    print('Brasil — homens:',f'{pop_br:,}',
          '| brancos:',f'{totais.loc["BR","BRANCOS"]:,}',
          '| negros:',f'{totais.loc["BR","NEGROS"]:,}',
          '| indígenas:',f'{totais.loc["BR","INDIGENAS"]:,}')
    auditoria = totais.reset_index()[['UF','COD_UF']+colunas_n].copy()
    auditoria['Soma faixas 8 idades OK'] = 'Sim'
    auditoria['Soma das categorias raciais OK'] = 'Sim'
    return denominadores, auditoria, zeros, df


def decodificar_idade(serie):
    """Preserva a regra aplicada na Tabela 1 v03, sem substituição silenciosa."""
    t = serie.astype('string').fillna('').str.strip()
    formato = t.str.fullmatch(r'[1-4]\d{3}').fillna(False)
    unidade = t.str.slice(0,1)
    n = pd.to_numeric(t.str.slice(1),errors='coerce')
    ano = pd.Series(np.nan, index=t.index, dtype='float64')
    for u, maximo in [('1',23),('2',31),('3',11)]:
        mascara = formato & unidade.eq(u) & n.between(0,maximo)
        ano.loc[mascara] = 0
    mascara = formato & unidade.eq('4') & n.between(0,120)
    ano.loc[mascara] = n.loc[mascara]
    return ano


def carregar_numeradores_parquet(caminho):
    print('\nETAPA 2/4 — Lendo Parquet e verificando universo da Tabela 1')
    if not caminho.exists():
        raise FileNotFoundError(f'Parquet ausente: {caminho}')
    pf = pq.ParquetFile(str(caminho))
    campos = ['ANO_ARQUIVO','DT_NOTIFIC','CS_SEXO','LES_AUTOP',
              'REL_PROPRI','CS_RACA','NU_IDADE_N','ID_MN_RESI']
    if not set(campos).issubset(pf.schema_arrow.names):
        falhar(f'Colunas ausentes no Parquet: {sorted(set(campos)-set(pf.schema_arrow.names))}')
    n_total = int(pf.metadata.num_rows)
    if n_total != CONTROLES_ESPERADOS['parquet']:
        falhar(f'Total de registros do Parquet: {n_total}; esperado {CONTROLES_ESPERADOS["parquet"]}')
    n_A_decada = 0
    n_ano_divergente = 0
    n_ano_invalido = 0
    partes = []
    for i, lote in enumerate(pf.iter_batches(columns=campos,batch_size=125_000),1):
        df = lote.to_pandas()
        sexo = df.CS_SEXO.astype('string').str.strip().str.upper()
        auto = normalizar_codigo(df.LES_AUTOP)
        anos = pd.to_numeric(df.ANO_ARQUIVO,errors='coerce')
        selecionados = df.loc[(sexo=='M').fillna(False) & (auto=='1').fillna(False)
                             & anos.between(2015,2024).fillna(False)].copy()
        n_A_decada += len(selecionados)
        if len(selecionados):
            dt = selecionados.DT_NOTIFIC.astype('string').fillna('').str.strip()
            anos_not = pd.to_numeric(dt.str.extract(r'^(20\d{2})')[0],errors='coerce')
            anos_arq = pd.to_numeric(selecionados.ANO_ARQUIVO,errors='coerce')
            n_ano_invalido += int(anos_not.isna().sum())
            n_ano_divergente += int((anos_not.notna() & anos_not.ne(anos_arq)).sum())
            if (anos_arq==ANO_ALVO).any():
                partes.append(selecionados.loc[anos_arq==ANO_ALVO].copy())
        if i%10==0:
            print(f'   Lote {i:02d}: {min(i*125000,n_total):,} registros do Parquet examinados')
    if n_A_decada != CONTROLES_ESPERADOS['2015_2024_A']:
        falhar(f'2015–2024 critério A {n_A_decada}; esperado 334.638')
    if n_ano_invalido or n_ano_divergente:
        falhar(f'Datas de notificação inválidas={n_ano_invalido}; divergências ano arquivo={n_ano_divergente}')
    if not partes:
        falhar('Nenhum registro de 2022 encontrado')
    base = pd.concat(partes,ignore_index=True)
    del partes
    if len(base)!=CONTROLES_ESPERADOS['2022_A']:
        falhar(f'2022 critério A contém {len(base)} registros; esperado 41.710')
    base['REL'] = normalizar_codigo(base.REL_PROPRI)
    base['RACA'] = normalizar_codigo(base.CS_RACA).map({
        '1':'Brancos', '2':'Negros', '4':'Negros', '5':'Indígenas',
        '3':'Amarelos'}).fillna('Não classificada')
    codigos_mun = base.ID_MN_RESI.astype('string').fillna('').str.strip()
    codigo_uf = codigos_mun.str.extract(r'^(\d{2})(?:\d{4}|\d{5})$')[0]
    base['UF'] = codigo_uf.map(UF_IBGE).fillna('SEM_UF')
    base['IDADE'] = decodificar_idade(base.NU_IDADE_N)
    base['FAIXA'] = pd.cut(base.IDADE,
        bins=[-1,9,14,19,24,29,44,59,np.inf],
        labels=FAIXAS).astype('string').fillna('SEM_IDADE')
    base['A'] = True
    base['B'] = base.REL.eq('1').fillna(False)
    base['C'] = base.IDADE.ge(10).fillna(False)
    base['D'] = base.B & base.C
    for c in CENARIOS:
        esperado = CONTROLES_ESPERADOS[f'2022_{c}']
        n = int(base[c].sum())
        if n!=esperado: falhar(f'Cenário {c} 2022: {n}; esperado {esperado}')
    if int(base.RACA.eq('Indígenas').sum()) != CONTROLES_ESPERADOS['2022_indigenas_A']:
        falhar('Numerador indígena 2022 diverge da auditoria do Script 02')
    if int(base.UF.eq('SEM_UF').sum()) != CONTROLES_ESPERADOS['2022_sem_uf_A']:
        falhar('Número de registros de 2022 sem UF difere do Script 02')
    if int(base.IDADE.isna().sum()) != CONTROLES_ESPERADOS['2022_idade_invalida_A']:
        falhar('Número de idades inválidas em 2022 diverge do Script 02')
    print('Controles SINAN confirmados: 334.638 (2015–2024), 41.710 (2022).')
    print('2022 — cenários:', ', '.join(f'{c}={int(base[c].sum()):,}' for c in CENARIOS))
    print('2022 — indígenas:',int(base.RACA.eq('Indígenas').sum()),
          '| idade inválida:',int(base.IDADE.isna().sum()),
          '| UF inválida:',int(base.UF.eq('SEM_UF').sum()))
    return base, n_A_decada, n_total


def poisson_exato(n, populacao):
    if populacao <= 0 or not np.isfinite(populacao):
        return (np.nan,np.nan,np.nan)
    if n < 0 or int(n)!=n: falhar('Contagem de notificações não inteira ou negativa')
    r = n/populacao*ESCALA
    li = (0.5*chi2.ppf(ALFA/2,2*n)/populacao*ESCALA) if n>0 else 0.0
    ls = 0.5*chi2.ppf(1-ALFA/2,2*(n+1))/populacao*ESCALA
    return (r,li,ls)


def fay_feuer_gamma(n_por_faixa,pop_por_faixa,pesos):
    """IC95% gama de Fay–Feuer (1997) para padronização direta.

    y = Σ(w_i * n_i / p_i); v = Σ(n_i * (w_i / p_i)^2);
    m = max(w_i / p_i);
    LI = Gamma^{-1}(alpha/2; forma=y²/v, escala=v/y), para v>0;
    LS = Gamma^{-1}(1-alpha/2; forma=(y+m)²/(v+m²),
                   escala=(v+m²)/(y+m)).
    Retorna taxas por 100 mil, variância e contagem ajustável.
    """
    n = np.asarray(n_por_faixa,dtype=float)
    pop = np.asarray(pop_por_faixa,dtype=float)
    w = np.asarray(pesos,dtype=float)
    if n.shape!=pop.shape or pop.shape!=w.shape or len(n)==0:
        falhar('Comprimentos incompatíveis de n, população e pesos para padronização')
    if (~np.isfinite(n)).any() or (n<0).any() or (n%1 != 0).any():
        falhar('Contagens etárias inválidas')
    if (~np.isfinite(pop)).any() or (pop<0).any() or (w<0).any():
        falhar('Denominadores ou pesos inválidos')
    if not np.isclose(w.sum(),1,atol=1e-10):
        falhar(f'Pesos de padronização não somam 1: {w.sum()}')
    if (pop==0).any():
        # Não substituir população zero por 1, interpolar ou eliminar faixa.
        if ((pop==0)&(n>0)).any():
            falhar('Há notificações em faixa etária com população censitária zero')
        return (np.nan,np.nan,np.nan,np.nan,'NÃO ESTIMÁVEL: população zero')
    a = w/pop
    y = float(np.sum(a*n))
    v = float(np.sum(a*a*n))
    m = float(np.max(a))
    if v>0:
        inf = float(gamma.ppf(ALFA/2,a=y*y/v,scale=v/y))
    else:
        inf = 0.0
    v2 = v + m*m
    y2 = y + m
    sup = float(gamma.ppf(1-ALFA/2,a=y2*y2/v2,scale=v2/y2))
    return (y*ESCALA,inf*ESCALA,sup*ESCALA,v*ESCALA**2,'OK')


def br_numero(x,casas=1):
    if pd.isna(x) or not np.isfinite(float(x)): return 'NE'
    return f'{float(x):,.{casas}f}'.replace(',','§').replace('.',',').replace('§','.')


def br_contagem(x):
    return f'{int(x):,}'.replace(',','.')


def br_ic(taxa,li,ls,casas=1):
    if not np.isfinite(taxa): return 'NE'
    return f'{br_numero(taxa,casas)} ({br_numero(li,casas)}–{br_numero(ls,casas)})'


def gerar_matrizes(base, denominadores):
    # Múltiplos cenários apenas para sensibilidade; a Tabela 2 usa o A.
    todas = []
    for crit in CENARIOS:
        elig = base.loc[base[crit]]
        # BR nacional inclui os 3 registros sem UF; UFs não.
        camadas = []
        for uf in ['BR'] + UFS:
            reg = elig if uf=='BR' else elig.loc[elig.UF==uf]
            pedacos = [reg.assign(RACA_CALC='Total')]
            pedacos.append(reg.loc[reg.RACA.isin(RACAS[1:])].assign(RACA_CALC=lambda d:d.RACA))
            bloco = pd.concat(pedacos,ignore_index=True)
            bloco['UF_CALC'] = uf
            camadas.append(bloco[['UF_CALC','RACA_CALC','FAIXA']])
        cont = pd.concat(camadas,ignore_index=True)
        cont['CENARIO'] = crit
        todas.append(cont)
    n = (pd.concat(todas,ignore_index=True)
         .groupby(['CENARIO','UF_CALC','RACA_CALC','FAIXA']).size()
         .rename('N').reset_index())
    n = n.rename(columns={'UF_CALC':'UF','RACA_CALC':'RACA'})
    grade = pd.MultiIndex.from_product(
        [CENARIOS,['BR']+UFS,RACAS,FAIXAS+['SEM_IDADE']],
        names=['CENARIO','UF','RACA','FAIXA']).to_frame(index=False)
    n = grade.merge(n,on=['CENARIO','UF','RACA','FAIXA'],how='left')
    n['N'] = n['N'].fillna(0).astype('int64')
    # Critérios C/D nunca incluem pessoas de 0–9 ou sem idade válida.
    for crit in ['C','D']:
        if n.loc[(n.CENARIO==crit)&n.FAIXA.isin(['0–9','SEM_IDADE']),'N'].sum()!=0:
            falhar('C/D contêm registros fora da faixa etária elegível')
    # Verificação de totais por cenário e UF; BR inclui sem UF e é independente da soma de UFs.
    for crit in CENARIOS:
        esperado = int(base[crit].sum())
        n_br = int(n.loc[(n.CENARIO==crit)&(n.UF=='BR')&(n.RACA=='Total'),'N'].sum())
        n_uf = int(n.loc[(n.CENARIO==crit)&(n.UF!='BR')&(n.RACA=='Total'),'N'].sum())
        sem_uf = int((base[crit]&base.UF.eq('SEM_UF')).sum())
        if n_br!=esperado or n_uf+sem_uf!=esperado:
            falhar(f'Numeradores incoerentes para {crit}: BR {n_br}, UFs {n_uf}, sem UF {sem_uf}, total {esperado}')
    # Compatibilidade etária numerador x denominador.
    taxas_idade = n.loc[n.FAIXA.isin(FAIXAS)].merge(
        denominadores, on=['UF','RACA','FAIXA'],how='left',validate='many_to_one')
    if taxas_idade.POPULACAO.isna().any():
        falhar('União SINAN × Censo deixou faixa sem denominador')
    if ((taxas_idade.POPULACAO==0)&(taxas_idade.N>0)).any():
        falhar('Notificações presentes em célula com denominador censitário zero')
    taxas_idade['TAXA_100MIL'] = np.where(taxas_idade.POPULACAO>0,
                                        taxas_idade.N/taxas_idade.POPULACAO*ESCALA,np.nan)
    return n, taxas_idade


def estimar_taxas(n, taxas_idade, denominadores, base):
    print('\nETAPA 3/4 — Taxas, IC95% exatos e padronização direta Fay–Feuer')
    totais = (denominadores.groupby(['UF','RACA'],as_index=False)['POPULACAO']
              .sum().rename(columns={'POPULACAO':'POP_TODAS'}))
    p10 = (denominadores.loc[denominadores.FAIXA!='0–9']
           .groupby(['UF','RACA'],as_index=False)['POPULACAO'].sum()
           .rename(columns={'POPULACAO':'POP_10MAIS'}))
    tot = totais.merge(p10,on=['UF','RACA'],validate='one_to_one')
    n_total = (n.groupby(['CENARIO','UF','RACA'],as_index=False)['N'].sum()
               .rename(columns={'N':'NOTIFICACOES'}))
    n_falta = (n.loc[n.FAIXA=='SEM_IDADE']
               .rename(columns={'N':'IDADE_INVALIDA_N'})[['CENARIO','UF','RACA','IDADE_INVALIDA_N']])
    taxas = n_total.merge(n_falta,on=['CENARIO','UF','RACA'],validate='one_to_one')
    taxas = taxas.merge(tot,on=['UF','RACA'],validate='many_to_one')
    pesos = denominadores.loc[(denominadores.UF=='BR')&(denominadores.RACA=='Total')].copy()
    pesos['FAIXA'] = pesos.FAIXA.astype(str)
    pesos = pesos.set_index('FAIXA').reindex(FAIXAS)
    if pesos.POPULACAO.isna().any(): falhar('Faltam faixas na população padrão BR')
    pesos_gerais = (pesos.POPULACAO/pesos.POPULACAO.sum()).to_numpy(dtype=float)
    pesos_10mais = pesos_gerais[1:]/pesos_gerais[1:].sum()
    lista_std = []
    for t in taxas.itertuples(index=False):
        if t.CENARIO in ['A','B']:
            pop = int(t.POP_TODAS)
            faixas_usadas = FAIXAS
            w = pesos_gerais
            universo = 'Todas as idades'
        else:
            pop = int(t.POP_10MAIS)
            faixas_usadas = FAIXAS[1:]
            w = pesos_10mais
            universo = 'Idade ≥10 anos'
        bruta,li_bruta,ls_bruta = poisson_exato(int(t.NOTIFICACOES),pop)
        sel = (taxas_idade.loc[(taxas_idade.CENARIO==t.CENARIO)
              & (taxas_idade.UF==t.UF)&(taxas_idade.RACA==t.RACA)&
              (taxas_idade.FAIXA.isin(faixas_usadas))].copy())
        sel['FAIXA'] = pd.Categorical(sel.FAIXA,categories=faixas_usadas,ordered=True)
        sel = sel.sort_values('FAIXA')
        if len(sel)!=len(faixas_usadas):
            falhar(f'Faltam faixas para {t.CENARIO}, {t.UF}, {t.RACA}')
        n_ajuste = int(sel.N.sum())
        if int(t.NOTIFICACOES) != n_ajuste+int(t.IDADE_INVALIDA_N):
            falhar('Contagem bruta não soma à contagem por faixas válidas + idade inválida')
        ajus,li_aj,ls_aj,var_aj,status = fay_feuer_gamma(sel.N.to_numpy(),
                                                         sel.POPULACAO.to_numpy(),w)
        flag = ('n<5: interpretação extremamente instável' if t.NOTIFICACOES<5 else
                'n<20: estimativa imprecisa' if t.NOTIFICACOES<20 else
                'n≥20 (IC95% ainda sujeito a pressupostos)')
        lista_std.append({
            'CENARIO':t.CENARIO,'UF':t.UF,'RACA':t.RACA,
            'Universo etário':universo,
            'Notificações (n)':int(t.NOTIFICACOES),
            'Idade inválida (n)':int(t.IDADE_INVALIDA_N),
            'Notificações com idade válida (n)':n_ajuste,
            'População masculina (n)':pop,
            'Taxa bruta/100 mil':bruta,'IC95% bruta LI':li_bruta,
            'IC95% bruta LS':ls_bruta,
            'Taxa padronizada/100 mil':ajus,'IC95% padronizada LI':li_aj,
            'IC95% padronizada LS':ls_aj,
            'Variância da taxa padronizada':var_aj,
            'Padronização':status,'Estabilidade':flag,
            'Taxa bruta (IC95%)':br_ic(bruta,li_bruta,ls_bruta),
            'Taxa padronizada (IC95%)':br_ic(ajus,li_aj,ls_aj)
        })
    resultado = pd.DataFrame(lista_std)
    resultado['ord_uf'] = resultado.UF.map({uf:i for i,uf in enumerate(['BR']+UFS)})
    resultado['ord_raca'] = resultado.RACA.map({r:i for i,r in enumerate(RACAS)})
    resultado = resultado.sort_values(['CENARIO','ord_uf','ord_raca']).drop(columns=['ord_uf','ord_raca'])
    if len(resultado)!=4*28*4:
        falhar('Número de estimativas inesperado: esperado 448')
    pesos_df = pd.DataFrame({
        'Faixa etária':FAIXAS,
        'População masculina Brasil 2022':pesos.POPULACAO.astype(int).to_numpy(),
        'Peso (todas as idades)':pesos_gerais,
        'Peso (≥10 anos)':np.concatenate(([0.0],pesos_10mais)),
    })
    return resultado,pesos_df


def razoes_taxas(taxas_A):
    linhas = []
    for uf in ['BR']+UFS:
        s = taxas_A.loc[taxas_A.UF==uf].set_index('RACA')
        ref = s.loc['Brancos']
        for raca in ['Negros','Indígenas']:
            linha = s.loc[raca]
            for tipo,col,var in [('Bruta','Taxa bruta/100 mil',None),
                                  ('Padronizada','Taxa padronizada/100 mil','Variância da taxa padronizada')]:
                n1,n0 = int(linha['Notificações (n)']),int(ref['Notificações (n)'])
                v1,v0 = float(linha[col]),float(ref[col])
                if not (np.isfinite(v1) and np.isfinite(v0) and v1>0 and v0>0):
                    rr,li,ls = np.nan,np.nan,np.nan
                    status='NE: taxa zero ou padronização não estimável'
                else:
                    rr=v1/v0
                    if n1<20 or n0<20:
                        li,ls=np.nan,np.nan
                        status='IC não apresentado: menos de 20 notificações em algum grupo'
                    else:
                        if tipo=='Bruta':
                            se=math.sqrt(1/n1+1/n0)  # Katz, grande amostra
                        else:
                            se=math.sqrt(float(linha[var])/v1**2 + float(ref[var])/v0**2)
                        li,ls=rr*math.exp(-norm.ppf(.975)*se),rr*math.exp(norm.ppf(.975)*se)
                        status='IC95% aproximado: log-normal/delta; pressupõe contagens Poisson independentes'
                linhas.append({'UF':uf,'Grupo no numerador':raca,
                               'Grupo de referência':'Brancos','Tipo de taxa':tipo,
                               'Notificações grupo (n)':n1,
                               'Notificações brancos (n)':n0,
                               'Razão de taxas':rr,
                               'IC95% LI':li,'IC95% LS':ls,
                               'Razão (IC95%)':br_ic(rr,li,ls,casas=2) if np.isfinite(li) else
                               (br_numero(rr,2)+' (IC NE)' if np.isfinite(rr) else 'NE'),
                               'Interpretação':status})
    return pd.DataFrame(linhas)


def tabela_publicacao(taxas):
    a=taxas.loc[taxas.CENARIO=='A']
    linhas=[]
    for uf in ['BR']+UFS:
        sub=a.loc[a.UF==uf].set_index('RACA')
        linha={'Brasil / UF': ('Brasil' if uf=='BR' else uf)}
        for raca in ['Brancos','Negros','Indígenas']:
            linha[f'{raca} — bruta (IC95%)'] = sub.loc[raca,'Taxa bruta (IC95%)']
        for raca in ['Brancos','Negros','Indígenas']:
            linha[f'{raca} — padronizada (IC95%)'] = sub.loc[raca,'Taxa padronizada (IC95%)']
        linha['Notificações indígenas (n)'] = int(sub.loc['Indígenas','Notificações (n)'])
        linha['Alerta indígena'] = sub.loc['Indígenas','Estabilidade']
        linhas.append(linha)
    return pd.DataFrame(linhas)


def auditar_taxas(taxas,base,denominadores,pesos):
    a=taxas.loc[taxas.CENARIO=='A']
    br = a[(a.UF=='BR')&(a.RACA=='Total')].iloc[0]
    if int(br['Notificações (n)']) != 41710:
        falhar('Taxa nacional não usa 41.710 notificações')
    if int(br['População masculina (n)']) != 98532431:
        falhar('Taxa nacional não usa 98.532.431 homens')
    if int(br['Idade inválida (n)'])!=124:
        falhar('Idades inválidas deveriam ser 124 em 2022')
    if (a['População masculina (n)']<=0).any():
        falhar('População zero/negativa na taxa bruta')
    if (a['IC95% bruta LI'] > a['Taxa bruta/100 mil']).any() or (a['Taxa bruta/100 mil']>a['IC95% bruta LS']).any():
        falhar('IC95% da taxa bruta não contém o ponto estimado')
    validos = a.loc[a.Padronização.eq('OK')]
    if ((validos['IC95% padronizada LI']>validos['Taxa padronizada/100 mil']) |
        (validos['Taxa padronizada/100 mil']>validos['IC95% padronizada LS'])).any():
        falhar('IC95% da taxa padronizada não contém estimativa')
    # Os quatro totais nacionais de notificações devem corresponder ao Script 02.
    for crit in CENARIOS:
        encontrado=int(taxas.loc[(taxas.CENARIO==crit)&(taxas.UF=='BR')&(taxas.RACA=='Total'),'Notificações (n)'].iloc[0])
        if encontrado != CONTROLES_ESPERADOS[f'2022_{crit}']:
            falhar(f'Controles da sensibilidade {crit} não conferem')
    auditoria = pd.DataFrame([
        ['Parquet original: registros todos os tipos',CONTROLES_ESPERADOS['parquet'],'Confere com Script 01/02'],
        ['SINAN 2022: notificações masculinas autoprovocadas — A',41710,'Todas as idades'],
        ['SINAN 2022: notificações masculinas autoprovocadas — B',39926,'REL_PROPRI=1'],
        ['SINAN 2022: notificações masculinas autoprovocadas — C',40945,'Idade >=10'],
        ['SINAN 2022: notificações masculinas autoprovocadas — D',39404,'REL_PROPRI=1 e idade >=10'],
        ['SINAN 2022: sem UF de residência válida',int((base.UF=='SEM_UF').sum()),'Preservados em Brasil e excluídos das 27 UFs'],
        ['SINAN 2022: idade inválida',int(base.IDADE.isna().sum()),'Preservada nas taxas brutas A/B'],
        ['SINAN 2022: indígenas — critério A',int((base.RACA=='Indígenas').sum()),'Conforme auditoria anterior'],
        ['Censo: linhas',616,'28 territórios × 22 faixas'],
        ['Censo: homens, Brasil',98532431,'Corresponde à soma das 27 UFs'],
        ['Censo: homens indígenas, Brasil',int(denominadores.loc[(denominadores.UF=='BR')&(denominadores.RACA=='Indígenas'),'POPULACAO'].sum()),'Cor/raça indígena, não pertencimento ampliado'],
        ['Peso padrão A/B: soma',round(pesos['Peso (todas as idades)'].sum(),12),'Deve ser 1,0'],
        ['Peso padrão C/D: soma',round(pesos['Peso (≥10 anos)'].sum(),12),'Deve ser 1,0'],
        ['Taxas brutas nacionais: notificações com idade ignorada incluídas',int(br['Idade inválida (n)']),'Taxa padronizada utiliza somente idades válidas'],
        ['Grupos UF×raça×cenário analisados',len(taxas),'28 × 4 × 4'],
        ['Método IC bruto','Poisson exato (qui-quadrado)','Não incorpora subnotificação'],
        ['Método IC ajustado','Gama de Fay–Feuer (1997)','Padronização direta, pesos homens Brasil 2022'],
        ['Razões de taxas','Log-normal (Katz bruto, delta padronizado)','Somente IC quando n>=20 em ambos os grupos'],
        ['Data/hora de execução',datetime.now().isoformat(timespec='seconds'),'Hora local da execução no Colab'],
        ['Python',platform.python_version(),'Ambiente'],
        ['pandas',pd.__version__,'Biblioteca'],
        ['SciPy',scipy.__version__,'Biblioteca'],
        ['PyArrow',pa.__version__,'Biblioteca'],
    ],columns=['Verificação','Valor','Interpretação / referência'])
    return auditoria


def exportar_excel(tabela,taxas,etarias,razoes,pesos,censo_audit,controles,zeros):
    print('\nETAPA 4/4 — Criando Excel auditável e legível')
    DESTINO.mkdir(parents=True,exist_ok=True)
    principal=taxas.loc[taxas.CENARIO=='A'].drop(columns=['CENARIO']).copy()
    sensibilidade=taxas.loc[taxas.CENARIO.isin(CENARIOS)].copy()
    idades=etarias.loc[etarias.CENARIO=='A'].copy()
    ordem={'BR':0,**{uf:i+1 for i,uf in enumerate(UFS)}}
    idades['ord_uf']=idades.UF.map(ordem)
    idades['ord_raca']=idades.RACA.map({r:i for i,r in enumerate(RACAS)})
    idades['ord_faixa']=idades.FAIXA.astype(str).map({f:i for i,f in enumerate(FAIXAS)})
    idades=idades.sort_values(['ord_uf','ord_raca','ord_faixa']).drop(columns=['ord_uf','ord_raca','ord_faixa'])
    idades=idades[['UF','RACA','FAIXA','N','POPULACAO','TAXA_100MIL']]
    idades.columns=['UF','Grupo racial','Faixa etária','Notificações (n)',
                   'População masculina (n)','Taxa específica/100 mil']
    sensibilidade=sensibilidade[['CENARIO','UF','RACA','Universo etário','Notificações (n)',
         'Idade inválida (n)','Notificações com idade válida (n)',
         'População masculina (n)','Taxa bruta/100 mil','IC95% bruta LI',
         'IC95% bruta LS','Taxa padronizada/100 mil',
         'IC95% padronizada LI','IC95% padronizada LS',
         'Estabilidade','Padronização']]
    notes=[
        ['OBJETO','Taxa de NOTIFICAÇÕES de lesão autoprovocada por 100.000 residentes masculinos, Brasil e UFs, ano 2022. Não mede incidência real de autolesão nem pessoas únicas.'],
        ['ARQUIVOS','Fonte numerador: SINAN_VIOLENCIA_2015_2024.parquet; denominador: censo2022_homens_uf_raca_idade.csv (SIDRA/IBGE tabela 9606).'],
        ['Tabela_2_Publicacao','Tabela editorial compacta: uma linha por UF, taxas brutas e padronizadas de brancos, negros e indígenas com IC95% entre parênteses.'],
        ['Taxas_2022_Detalhe','Numerador, denominador, idade desconhecida, taxas e intervalos numéricos para Total, Brancos, Negros e Indígenas (critério A).'],
        ['Taxas_por_Idade','Taxas específicas por oito faixas etárias, UF e raça/cor (critério A). Células com população zero geram taxa não estimável, nunca divisão arbitrária.'],
        ['Razoes_Taxas','Negros/brancos e indígenas/brancos, brutas e padronizadas; IC aproximado somente quando ambos numeradores >=20.'],
        ['Sensibilidade_A_B_C_D','Cenários A: LES_AUTOP=1; B: A+REL_PROPRI=1; C: A+idade>=10; D: B+idade>=10. Todos usam UF de residência.'],
        ['Auditoria_Censo_2022','Totais censitários da população masculina por UF, cor/raça e verificações de consistência.'],
        ['Pesos_Padrao_2022','Pesos de cada faixa na população masculina brasileira Censo 2022: padrão todas as idades, e padrão >=10.'],
        ['Controles_e_Metodos','Contagens de controle, definição das estimativas e versões de bibliotecas.'],
        ['IC bruto','Poisson exato, utilizando quantis qui-quadrado (Garwood); adequado para pequenas contagens e zero observações.'],
        ['IC padronizado','Gamma conservadora de Fay–Feuer (1997), calculada por pesos da população masculina brasileira de 2022.'],
        ['População padrão','TODOS os homens do Brasil em 2022, independentemente da cor/raça; não usar estrutura etária racial como padrão.'],
        ['A/B: denominadores','População masculina de todas as idades, mesmo que o numerador tenha idade ignorada. Para taxa ajustada, excluir somente idades inválidas e informá-las.'],
        ['C/D: denominadores','Restringir a homens com idade >=10 no Censo; padronização utiliza pesos padrão do Brasil com >=10 anos renormalizados.'],
        ['Raça/cor indígena','Censo: cor ou raça indígena conforme quesito da tabela 9606, não estimativa ampliada de pertencimento étnico.'],
        ['Raça/cor negra','SINAN preto (2)+pardo (4); Censo PRETOS+PARDOS no arquivo de denominadores.'],
        ['Categoria Total','Numerador inclui todas as raças, inclusive amarelos e raça ignorada, e toda população masculina no denominador.'],
        ['UF de residência','Extraída do prefixo do código municipal ID_MN_RESI; registros SEM_UF integram Brasil, mas não qualquer UF.'],
        ['Estimativas instáveis','Marcar n<5 ou n<20 no detalhamento; os IC95% de Poisson/Fay–Feuer são calculados mesmo com n pequeno, quando estimáveis.'],
        ['Razões: ressalvas','IC95% de RR é aproximação log-normal; com menos de 20 notificações em algum grupo, ponto pode ser mostrado, mas IC é não estimado.'],
        ['Comparação A x C','Não interpretar diferença nas taxas como efeito único de qualidade: o universo etário também muda. Comparar A/B e C/D em pares.'],
        ['Idade ausente','Idades não codificáveis entram em A/B bruta; não entram na ajustada; C/D as excluem inteiramente.'],
        ['Ausências de registro','IC95% não corrigem subnotificação, duplicidade, seleção pelo serviço de saúde ou preenchimento diferencial.'],
        ['Formato','Valores numéricos preservados nas abas técnicas; representação BR nas células de apresentação. Séries e mapas posteriores sairão em BR e US (SVG e JPEG 400 dpi).'],
        ['Fonte IBGE','https://sidra.ibge.gov.br/tabela/9606'],
        ['Fonte método gama','Fay MP, Feuer EJ. Stat Med. 1997;16:791–801. https://pubmed.ncbi.nlm.nih.gov/9131766/'],
    ]
    abas={
        'LEIA_PRIMEIRO':pd.DataFrame(notes,columns=['Assunto','Instrução / nota metodológica']),
        'Tabela_2_Publicacao':tabela,
        'Taxas_2022_Detalhe':principal,
        'Taxas_por_Idade':idades,
        'Razoes_Taxas':razoes,
        'Sensibilidade_A_B_C_D':sensibilidade,
        'Auditoria_Censo_2022':censo_audit,
        'Pesos_Padrao_2022':pesos,
        'Controles_e_Metodos':controles,
    }
    # openpyxl dispensa a instalação adicional do xlsxwriter (erro do Script 02).
    with pd.ExcelWriter(SAIDA,engine='openpyxl') as writer:
        for nome,quadro in abas.items():
            quadro.to_excel(writer,sheet_name=nome,index=False)
    livro=load_workbook(SAIDA)
    cor_azul='1E3A56'; cor_cinza='EAF1F4'; cor_branco='FFFFFF'; cor_texto='1E2A33'
    cor_sub='E5F2EF'
    for aba in livro.worksheets:
        aba.freeze_panes='B2'
        aba.sheet_view.showGridLines=False
        aba.auto_filter.ref=aba.dimensions
        aba.row_dimensions[1].height=35
        for celula in aba[1]:
            celula.fill=PatternFill('solid',fgColor=cor_azul)
            celula.font=Font(name='Aptos',size=10,bold=True,color=cor_branco)
            celula.alignment=Alignment(vertical='center',wrap_text=True)
        for row in aba.iter_rows(min_row=2):
            for celula in row:
                celula.font=Font(name='Aptos',size=10,color=cor_texto)
                celula.alignment=Alignment(vertical='center',wrap_text=False)
                if celula.row%2==0:
                    celula.fill=PatternFill('solid',fgColor='F5F8FA')
                if isinstance(celula.value,(int,float)) and not isinstance(celula.value,bool):
                    if isinstance(celula.value,int) or float(celula.value).is_integer():
                        celula.number_format='#,##0'
                    else:
                        celula.number_format='#,##0.0000'
        for ci,col in enumerate(aba.columns,1):
            valores=[str(c.value or '') for c in list(col)[:350]]
            maxlen=max((len(v) for v in valores),default=10)
            if aba.title=='LEIA_PRIMEIRO':
                largura=33 if ci==1 else 105
            elif aba.title=='Tabela_2_Publicacao':
                largura=14 if ci==1 else (30 if ci in range(2,8) else 38)
            elif ci==1:
                largura=21
            else:
                largura=max(14,min(49,maxlen+3))
            aba.column_dimensions[get_column_letter(ci)].width=largura
        if aba.title=='LEIA_PRIMEIRO':
            aba.column_dimensions['A'].width=32
            aba.column_dimensions['B'].width=112
            for row in aba.iter_rows(min_row=2):
                row[1].alignment=Alignment(wrap_text=True,vertical='top')
                aba.row_dimensions[row[0].row].height=28 if len(str(row[1].value))<160 else 42
        if aba.title=='Tabela_2_Publicacao':
            aba.freeze_panes='B2'
            for celula in aba[2]:
                celula.fill=PatternFill('solid',fgColor=cor_sub)
                celula.font=Font(name='Aptos',size=10,bold=True,color=cor_azul)
            for row in aba.iter_rows(min_row=2):
                row[-1].alignment=Alignment(wrap_text=True)
        if aba.title=='Controles_e_Metodos':
            aba.column_dimensions['A'].width=65
            aba.column_dimensions['B'].width=43
            aba.column_dimensions['C'].width=75
    livro.save(SAIDA)
    print('Arquivo Excel produzido:',SAIDA)
    print('Abas:',', '.join(abas.keys()))
    return SAIDA


def executar():
    print('SCRIPT 03 — TAXAS SINAN × CENSO, 2022')
    print('Referência: protocolo metodológico v0.5; resultados de Scripts 01 e 02.')
    den,aud,zeros,censo = carregar_e_auditar_censo(CENSO)
    base, n_decada, n_total = carregar_numeradores_parquet(PARQUET)
    numeradores,idades = gerar_matrizes(base,den)
    taxas,pesos=estimar_taxas(numeradores,idades,den,base)
    audit=auditar_taxas(taxas,base,den,pesos)
    principal=taxas.loc[taxas.CENARIO=='A']
    quadro=tabela_publicacao(taxas)
    rr=razoes_taxas(principal)
    arquivo=exportar_excel(quadro,taxas,idades,rr,pesos,aud,audit,zeros)
    print('\nVISUALIZAÇÃO BRASIL — cenário A:')
    cols=['RACA','Notificações (n)','População masculina (n)',
          'Taxa bruta (IC95%)','Taxa padronizada (IC95%)','Estabilidade']
    print(principal.loc[principal.UF=='BR',cols].to_string(index=False))
    print('\nATENÇÃO: há',int((principal['Notificações (n)']<20).sum()),
          'linhas UF × grupo com <20 notificações. Interpretar estimativas indígenas com cautela.')
    print('Concluído. Não foram alterados os arquivos de origem.')
    return arquivo


if __name__=='__main__':
    executar()
