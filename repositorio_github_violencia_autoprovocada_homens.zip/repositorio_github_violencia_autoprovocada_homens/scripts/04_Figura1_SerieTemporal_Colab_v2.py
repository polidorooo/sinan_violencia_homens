from pathlib import Path
import zipfile
import pandas as pd
import pyarrow.parquet as pq
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

# ============================================================
# SCRIPT 04 — FIGURA 1
# Violência autoprovocada em homens no Brasil, 2015–2024
# Produto: série temporal por raça/cor (Brancos, Negros, Indígenas)
# Saídas: SVG + JPEG (BR e US) + base analítica em XLSX/CSV
# ============================================================

BASE = Path('/content')
ARQ_PARQUET = BASE / 'SINAN_VIOLENCIA_2015_2024.parquet'
SAIDA = BASE / 'RESULTADOS_ARTIGO' / '04_figura1'
SAIDA.mkdir(parents=True, exist_ok=True)

if not ARQ_PARQUET.exists():
    raise FileNotFoundError(f'Arquivo não encontrado: {ARQ_PARQUET}')

RACAS = {
    '1': 'Brancos',
    '2': 'Negros',
    '4': 'Negros',
    '5': 'Indígenas',
    '3': 'Amarelos',
    '9': 'Ignorado'
}

GRUPOS_FIGURA = ['Brancos', 'Negros', 'Indígenas']

UF_CODIGOS = {
    '11':'RO', '12':'AC', '13':'AM', '14':'RR', '15':'PA', '16':'AP', '17':'TO',
    '21':'MA', '22':'PI', '23':'CE', '24':'RN', '25':'PB', '26':'PE', '27':'AL',
    '28':'SE', '29':'BA', '31':'MG', '32':'ES', '33':'RJ', '35':'SP', '41':'PR',
    '42':'SC', '43':'RS', '50':'MS', '51':'MT', '52':'GO', '53':'DF'
}


def normalizar(serie):
    return (
        serie.astype('string')
        .str.strip()
        .str.upper()
        .fillna('')
    )


# ============================================================
# 1. LEITURA PROGRESSIVA DO PARQUET
# ============================================================
pf = pq.ParquetFile(str(ARQ_PARQUET))

COLUNAS = ['ANO_ARQUIVO', 'CS_SEXO', 'LES_AUTOP', 'CS_RACA']
faltantes = set(COLUNAS) - set(pf.schema_arrow.names)
if faltantes:
    raise ValueError(f'Colunas ausentes no Parquet: {faltantes}')

partes = []
controles = []
total_lido = 0
selecionados = 0

for i, lote in enumerate(pf.iter_batches(batch_size=100000, columns=COLUNAS), start=1):
    df = lote.to_pandas()
    total_lido += len(df)

    sexo = normalizar(df['CS_SEXO'])
    autop = normalizar(df['LES_AUTOP'])
    mask = (sexo.eq('M') & autop.eq('1')).fillna(False)
    df = df.loc[mask].copy()

    if df.empty:
        continue

    selecionados += len(df)

    df['ANO'] = pd.to_numeric(df['ANO_ARQUIVO'], errors='raise').astype(int)
    raca = normalizar(df['CS_RACA'])
    df['RACA'] = raca.map(RACAS).fillna('Ignorado')

    partes.append(
        df.groupby(['ANO', 'RACA'], as_index=False)
          .size()
          .rename(columns={'size': 'N'})
    )

    controles.append({
        'lote': i,
        'registros_lidos_lote': len(lote),
        'registros_selecionados_lote': len(df)
    })

serie = (
    pd.concat(partes, ignore_index=True)
      .groupby(['ANO', 'RACA'], as_index=False)['N'].sum()
)

serie_fig = (
    serie.loc[serie['RACA'].isin(GRUPOS_FIGURA)]
         .copy()
)

# grade completa 2015-2024 x 3 grupos
anos = pd.DataFrame({'ANO': list(range(2015, 2025))})
grupos = pd.DataFrame({'RACA': GRUPOS_FIGURA})
grade = anos.merge(grupos, how='cross')
serie_fig = grade.merge(serie_fig, on=['ANO', 'RACA'], how='left').fillna({'N': 0})
serie_fig['N'] = serie_fig['N'].astype(int)

# Controle final
controle_resumo = pd.DataFrame([
    {'indicador': 'Registros no Parquet (metadados)', 'valor': int(pf.metadata.num_rows)},
    {'indicador': 'Registros lidos', 'valor': int(total_lido)},
    {'indicador': 'Notificações masculinas de lesão autoprovocada', 'valor': int(selecionados)},
    {'indicador': 'Notificações incluídas na figura (Brancos+Negros+Indígenas)', 'valor': int(serie_fig['N'].sum())}
])

# ============================================================
# 2. EXPORTAÇÃO DA BASE DA FIGURA
# ============================================================
arq_xlsx = SAIDA / '04_Figura_1_base_e_controles.xlsx'
arq_csv = SAIDA / '04_Figura_1_serie_temporal.csv'

with pd.ExcelWriter(arq_xlsx, engine='openpyxl') as writer:
    serie_fig.to_excel(writer, sheet_name='Serie_temporal_figura', index=False)
    serie.to_excel(writer, sheet_name='Serie_completa_racas', index=False)
    pd.DataFrame(controles).to_excel(writer, sheet_name='Controles_lotes', index=False)
    controle_resumo.to_excel(writer, sheet_name='Resumo', index=False)
    pd.DataFrame([
        {'item': 'População analítica', 'descricao': 'Registros com CS_SEXO = M e LES_AUTOP = 1.'},
        {'item': 'Grupos na figura', 'descricao': 'Brancos (CS_RACA=1), Negros (CS_RACA=2 ou 4) e Indígenas (CS_RACA=5).'},
        {'item': 'Eixo Y', 'descricao': 'Número anual de notificações.'},
        {'item': 'Observação', 'descricao': 'Figura sem título incorporado. Título e legenda serão inseridos no manuscrito.'},
        {'item': 'Versões', 'descricao': 'Arquivos BR e US diferem apenas na convenção numérica e idioma dos eixos/notas.'}
    ]).to_excel(writer, sheet_name='LEIA_PRIMEIRO', index=False)

serie_fig.to_csv(arq_csv, index=False, encoding='utf-8-sig')

# ============================================================
# 3. FIGURA — FUNÇÕES AUXILIARES
# ============================================================

def fmt_int_br(x, pos=None):
    try:
        return f'{int(round(x)):,}'.replace(',', '.')
    except Exception:
        return ''


def fmt_int_us(x, pos=None):
    try:
        return f'{int(round(x)):,}'
    except Exception:
        return ''


def gerar_figura(locale='BR'):
    if locale == 'BR':
        ylabel = 'Número de notificações'
        xlabel = 'Ano de notificação'
        nota = 'Fonte: SINAN, 2015–2024. Elaboração própria.'
        formatter = FuncFormatter(fmt_int_br)
        prefixo = 'Figura_1_BR'
    else:
        ylabel = 'Number of notifications'
        xlabel = 'Year of notification'
        nota = 'Source: SINAN, 2015–2024. Authors\' elaboration.'
        formatter = FuncFormatter(fmt_int_us)
        prefixo = 'Figura_1_US'

    fig, axes = plt.subplots(nrows=3, ncols=1, figsize=(8.3, 8.8), sharex=True)

    for idx, (ax, grupo) in enumerate(zip(axes, GRUPOS_FIGURA), start=1):
        dados = serie_fig.loc[serie_fig['RACA'].eq(grupo)].sort_values('ANO')
        ax.plot(dados['ANO'], dados['N'], marker='o', linewidth=1.8)
        ax.yaxis.set_major_formatter(formatter)
        ax.set_ylabel(ylabel, fontsize=10)
        ax.set_xlim(2015, 2024)
        ax.set_xticks(range(2015, 2025))
        ax.grid(axis='y', alpha=0.25)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.tick_params(axis='both', labelsize=9)
        ax.text(0.0, 1.03, f'{chr(64+idx)}. {grupo}', transform=ax.transAxes,
                ha='left', va='bottom', fontsize=11, fontweight='bold')

    # Formatação definitiva dos eixos Y, após toda a diagramação.
    # Matplotlib pode redefinir formatadores se alguma função de estilo
    # for executada depois de set_major_formatter.
    for ax in axes:
        ax.yaxis.set_major_formatter(formatter)
        ax.yaxis.get_offset_text().set_visible(False)

    axes[-1].set_xlabel(xlabel, fontsize=10)
    fig.text(0.99, 0.01, nota, ha='right', va='bottom', fontsize=8)
    plt.tight_layout(rect=[0, 0.03, 1, 1])
    fig.canvas.draw()
    # Controle de qualidade: contagens de 5 dígitos DEVEM conter
    # separador de milhar na versão BR e US.
    amostra = formatter(20000)
    esperado = '20.000' if locale == 'BR' else '20,000'
    if amostra != esperado:
        raise AssertionError(f'Formatação de milhar incorreta: {amostra!r} != {esperado!r}')

    arq_svg = SAIDA / f'{prefixo}.svg'
    arq_jpg = SAIDA / f'{prefixo}.jpeg'
    fig.savefig(arq_svg, bbox_inches='tight')
    fig.savefig(arq_jpg, dpi=400, bbox_inches='tight')
    plt.close(fig)


gerar_figura('BR')
gerar_figura('US')

print('\nSCRIPT 04 CONCLUÍDO')
print(f'Base da figura: {arq_xlsx}')
print(f'CSV da figura: {arq_csv}')
print(f'Figura BR SVG: {SAIDA / "Figura_1_BR.svg"}')
print(f'Figura BR JPEG: {SAIDA / "Figura_1_BR.jpeg"}')
print(f'Figura US SVG: {SAIDA / "Figura_1_US.svg"}')
print(f'Figura US JPEG: {SAIDA / "Figura_1_US.jpeg"}')
