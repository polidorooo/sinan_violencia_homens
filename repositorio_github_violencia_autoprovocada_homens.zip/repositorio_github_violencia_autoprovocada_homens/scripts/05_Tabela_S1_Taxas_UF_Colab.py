"""SCRIPT 05 — TABELA SUPLEMENTAR S1

Gera uma única tabela editorial estadual a partir do Excel ORIGINAL
produzido pelo Script 03 no Google Colab. NÃO recalcula taxas.

Entrada obrigatória: 03_taxas_violencia_autoprovocada_2022.xlsx
Aba: Taxas_2022_Detalhe

Saída: /content/RESULTADOS_ARTIGO/05_suplemento/
- Tabela_S1_taxas_UF_raca_2022.xlsx
- Tabela_S1_publicacao_BR.csv
"""

from pathlib import Path
import re

import pandas as pd
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.page import PageMargins

# ============================================================== 
# 0. CONFIGURAÇÃO E LOCALIZAÇÃO DO ARQUIVO ORIGINAL
# ============================================================== 
RAIZ = Path('/content')
SAIDA = RAIZ / 'RESULTADOS_ARTIGO' / '05_suplemento'
SAIDA.mkdir(parents=True, exist_ok=True)
NOME_FONTE = '03_taxas_violencia_autoprovocada_2022.xlsx'
ARQUIVO_FONTE = RAIZ / NOME_FONTE

if not ARQUIVO_FONTE.is_file():
    encontrados = [p for p in RAIZ.rglob(NOME_FONTE) if p.is_file()]
    # Se o usuário mantiver diversas cópias, preferir a mais recente.
    if encontrados:
        ARQUIVO_FONTE = max(encontrados, key=lambda p: p.stat().st_mtime)
        print(f'Arquivo localizado automaticamente: {ARQUIVO_FONTE}')
    else:
        print(f'Não encontrei {NOME_FONTE} na sessão atual.')
        print('Envie o Excel ORIGINAL do Script 03 pelo botão de arquivos do Colab.')
        print('Vou abrir a seleção de arquivos para facilitar.')
        try:
            from google.colab import files
            enviados = files.upload()
            if NOME_FONTE in enviados:
                ARQUIVO_FONTE = RAIZ / NOME_FONTE
            else:
                raise FileNotFoundError(
                    f'É necessário enviar o arquivo denominado {NOME_FONTE}; '
                    f'arquivos recebidos: {list(enviados)}'
                )
        except ImportError as erro:
            raise FileNotFoundError(
                f'Arquivo original não encontrado em {RAIZ}. '
                'Copie o Excel do Script 03 para essa pasta.'
            ) from erro

# ============================================================== 
# 1. LEITURA E CONTROLES
# ============================================================== 
df = pd.read_excel(ARQUIVO_FONTE, sheet_name='Taxas_2022_Detalhe', engine='openpyxl')
COLUNAS = {
    'UF', 'RACA', 'Notificações (n)', 'População masculina (n)',
    'Taxa bruta/100 mil', 'IC95% bruta LI', 'IC95% bruta LS',
    'Taxa padronizada/100 mil', 'IC95% padronizada LI', 'IC95% padronizada LS',
    'Notificações com idade válida (n)', 'Idade inválida (n)'
}
faltam = COLUNAS - set(df.columns)
if faltam:
    raise ValueError(f'Colunas ausentes na aba Taxas_2022_Detalhe: {sorted(faltam)}')

REGIOES = {
    'Norte': ['RO', 'AC', 'AM', 'RR', 'PA', 'AP', 'TO'],
    'Nordeste': ['MA', 'PI', 'CE', 'RN', 'PB', 'PE', 'AL', 'SE', 'BA'],
    'Sudeste': ['MG', 'ES', 'RJ', 'SP'],
    'Sul': ['PR', 'SC', 'RS'],
    'Centro-Oeste': ['MS', 'MT', 'GO', 'DF'],
}
ORDEM_UF = [uf for ufs in REGIOES.values() for uf in ufs]
REGIAO_POR_UF = {uf: reg for reg, ufs in REGIOES.items() for uf in ufs}
RACAS = ['Brancos', 'Negros', 'Indígenas']

if len(ORDEM_UF) != 27 or len(set(ORDEM_UF)) != 27:
    raise AssertionError('Mapa de regiões inválido: devem existir 27 UFs distintas.')

df['UF'] = df['UF'].astype(str).str.strip().str.upper()
df['RACA'] = df['RACA'].astype(str).str.strip()
sub = df.loc[df['UF'].isin(ORDEM_UF) & df['RACA'].isin(RACAS)].copy()

if len(sub) != 81:
    raise AssertionError(f'Esperadas 81 combinações UF × raça; encontradas {len(sub)}.')
if sub.duplicated(['UF', 'RACA']).any():
    raise AssertionError('Existem combinações UF × raça duplicadas.')

for coluna in [
    'Notificações (n)', 'População masculina (n)',
    'Taxa padronizada/100 mil', 'IC95% padronizada LI', 'IC95% padronizada LS'
]:
    sub[coluna] = pd.to_numeric(sub[coluna], errors='raise')
    if sub[coluna].isna().any():
        raise ValueError(f'Valores não estimáveis em {coluna}. Conferir origem.')

if (sub['Notificações (n)'] < 0).any() or (sub['População masculina (n)'] <= 0).any():
    raise AssertionError('Numeradores negativos ou denominadores não positivos.')

if not (
    (sub['IC95% padronizada LI'] <= sub['Taxa padronizada/100 mil']) &
    (sub['Taxa padronizada/100 mil'] <= sub['IC95% padronizada LS'])
).all():
    raise AssertionError('Taxa padronizada fora do IC95% em ao menos uma linha.')

br = df.loc[(df['UF'] == 'BR') & df['RACA'].isin(RACAS)].copy()
if len(br) != 3:
    raise AssertionError('Totais nacionais por raça ausentes na fonte.')

# Há até três notificações em 2022 sem UF de residência, conforme auditoria.
controle_uf = []
for raca in RACAS:
    nacional = int(br.loc[br['RACA'] == raca, 'Notificações (n)'].iloc[0])
    estaduais = int(sub.loc[sub['RACA'] == raca, 'Notificações (n)'].sum())
    perda = nacional - estaduais
    if not (0 <= perda <= 3):
        raise AssertionError(
            f'Raça {raca}: diferença inesperada Brasil vs UFs: {perda}'
        )
    controle_uf.append({
        'Raça/cor': raca,
        'Notificações nacionais': nacional,
        'Soma das notificações estaduais': estaduais,
        'Notificações sem UF válida': perda,
        'Resultado': 'Conferido'
    })

# ============================================================== 
# 2. FORMATAÇÃO PARA PUBLICAÇÃO — SEM RECÁLCULO DAS TAXAS
# ============================================================== 
def numero_br(valor):
    return f'{float(valor):.1f}'.replace('.', ',')


def taxa_ic_br(linha):
    return (
        f"{numero_br(linha['Taxa padronizada/100 mil'])} "
        f"({numero_br(linha['IC95% padronizada LI'])}–"
        f"{numero_br(linha['IC95% padronizada LS'])})"
    )

linhas = []
for regiao, ufs in REGIOES.items():
    for uf in ufs:
        registro = {'Grande região': regiao, 'UF': uf}
        for raca in RACAS:
            linha = sub.loc[(sub['UF'] == uf) & (sub['RACA'] == raca)].iloc[0]
            n = int(linha['Notificações (n)'])
            registro[f'{raca} — n'] = n
            # O marcador † sinaliza o tamanho do numerador, não altera a estimativa.
            registro[f'{raca} — taxa padronizada (IC95%)'] = (
                taxa_ic_br(linha) + ('†' if n < 20 else '')
            )
        linhas.append(registro)

publicacao = pd.DataFrame(linhas)
if len(publicacao) != 27:
    raise AssertionError('Tabela editorial deveria apresentar 27 UFs.')

# Para auditoria, manter todas as estimativas numéricas originais (inclusive brutas).
sub['Grande região'] = sub['UF'].map(REGIAO_POR_UF)
sub['Ordem da UF'] = sub['UF'].map({uf: i for i, uf in enumerate(ORDEM_UF)})
sub['Ordem de raça'] = sub['RACA'].map({r: i for i, r in enumerate(RACAS)})
sub = sub.sort_values(['Ordem da UF', 'Ordem de raça']).drop(
    columns=['Ordem da UF', 'Ordem de raça']
)

ARQ_XLSX = SAIDA / 'Tabela_S1_taxas_UF_raca_2022.xlsx'
ARQ_CSV = SAIDA / 'Tabela_S1_publicacao_BR.csv'

nota_geral = (
    'Taxas de notificações por 100 mil homens residentes, padronizadas por idade '
    'pelo método direto; padrão: população masculina brasileira do Censo 2022, '
    'independentemente da raça/cor. IC95% pelo método gama de Fay–Feuer.'
)
nota_simbolo = (
    '† Estimativa baseada em menos de 20 notificações; interpretar com cautela. '
    'Taxa igual a zero indica ausência de notificações registradas na UF, '
    'não ausência de eventos ou risco.'
)
nota_grupos = (
    'Negros = pretos + pardos. Indígenas conforme cor ou raça do SINAN e do '
    'Censo 2022. O total nacional inclui também outras categorias raciais.'
)
nota_origem = (
    'Fonte: SINAN 2022 (notificações) e IBGE, Censo Demográfico 2022, '
    'tabela SIDRA 9606 (população).'
)

# ============================================================== 
# 3. ARQUIVO XLSX COM UMA TABELA SUPLEMENTAR EDITORIAL
# ============================================================== 
with pd.ExcelWriter(ARQ_XLSX, engine='openpyxl') as writer:
    # Na aba editorial, cabeçalho e notas são inseridos após a exportação.
    publicacao.to_excel(writer, sheet_name='Tabela_S1', index=False, startrow=3)
    sub.to_excel(writer, sheet_name='Dados_tecnicos', index=False)
    pd.DataFrame(controle_uf).to_excel(writer, sheet_name='Controles', index=False)

    livro = writer.book
    ws = livro['Tabela_S1']
    ws['A1'] = (
        'Tabela S1. Taxas padronizadas por idade de notificações de violência '
        'autoprovocada por 100 mil homens, segundo raça/cor e UF. Brasil, 2022.'
    )
    ws.merge_cells('A1:H2')
    ws['A1'].font = Font(name='Aptos', size=12, bold=True, color='19324C')
    ws['A1'].alignment = Alignment(vertical='center', wrap_text=True)
    ws.row_dimensions[1].height = 25
    ws.row_dimensions[2].height = 25
    ws.row_dimensions[3].height = 9
    ws.row_dimensions[4].height = 40

    # A4:H4 contém os cabeçalhos; A5:H31 contém as 27 UFs.
    paleta = {
        'header': '1E435D',
        'header_text': 'FFFFFF',
        'alternate': 'F0F5F8',
        'divider': '8EA8BA',
        'text': '243546',
        'indigena': 'EAF3EF'
    }
    cab = ws[4]
    for celula in cab:
        celula.fill = PatternFill('solid', fgColor=paleta['header'])
        celula.font = Font(name='Aptos', size=10, bold=True, color=paleta['header_text'])
        celula.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        celula.border = Border(bottom=Side(style='medium', color=paleta['divider']))

    # Visual mais leve sem linhas verticais; divisor em cada mudança de região.
    ultima_regiao = None
    for idx, row in enumerate(ws.iter_rows(min_row=5, max_row=31, min_col=1, max_col=8), start=5):
        atual = ws.cell(idx, 1).value
        mudou = atual != ultima_regiao
        for col, cell in enumerate(row, start=1):
            fundo = 'FFFFFF' if idx % 2 else paleta['alternate']
            if col == 8:
                fundo = paleta['indigena']
            cell.fill = PatternFill('solid', fgColor=fundo)
            cell.font = Font(name='Aptos', size=10, color=paleta['text'],
                             bold=(col <= 2))
            cell.alignment = Alignment(
                vertical='center', horizontal=('left' if col <= 2 else 'center')
            )
            if mudou:
                cell.border = Border(top=Side(style='thin', color=paleta['divider']))
        ws.row_dimensions[idx].height = 21
        ultima_regiao = atual

    larguras = [19, 8, 13, 29, 13, 29, 14, 30]
    for i, largura in enumerate(larguras, start=1):
        ws.column_dimensions[get_column_letter(i)].width = largura
    ws.freeze_panes = 'C5'
    ws.sheet_view.showGridLines = False
    ws.print_options.horizontalCentered = True
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 2
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.paperSize = ws.PAPERSIZE_A3
    ws.print_title_rows = '1:4'
    ws.print_area = 'A1:H38'
    ws.page_margins = PageMargins(left=0.25, right=0.25, top=0.4, bottom=0.45,
                                  header=0.15, footer=0.2)

    notas = [nota_geral, nota_simbolo, nota_grupos, nota_origem]
    for i, texto in enumerate(notas, start=33):
        ws.merge_cells(start_row=i, start_column=1, end_row=i, end_column=8)
        celula = ws.cell(i, 1, texto)
        celula.alignment = Alignment(vertical='top', wrap_text=True)
        celula.font = Font(name='Aptos', size=9, color='555E67')
        ws.row_dimensions[i].height = 30 if i in (33, 34) else 22

    for auxiliar in ['Dados_tecnicos', 'Controles']:
        aba = livro[auxiliar]
        aba.freeze_panes = 'A2'
        aba.sheet_view.showGridLines = False
        aba.row_dimensions[1].height = 32
        for c in aba[1]:
            c.fill = PatternFill('solid', fgColor=paleta['header'])
            c.font = Font(name='Aptos', color='FFFFFF', bold=True)
            c.alignment = Alignment(wrap_text=True, vertical='center')
        for c in aba[1]:
            aba.column_dimensions[c.column_letter].width = min(34, max(13, len(str(c.value)) + 2))

publicacao.to_csv(ARQ_CSV, index=False, encoding='utf-8-sig', sep=';')

# ============================================================== 
# 4. VERIFICAÇÕES FINAIS E RESUMO
# ============================================================== 
conferir = pd.read_excel(ARQ_XLSX, sheet_name='Tabela_S1', header=3, nrows=27)
if len(conferir) != 27:
    raise AssertionError(f'Arquivo final deveria ter 27 linhas; tem {len(conferir)}')
if list(conferir['UF']) != ORDEM_UF:
    raise AssertionError('Ordem das UFs mudou na exportação.')

for uf in ORDEM_UF:
    row = conferir.loc[conferir['UF'].eq(uf)].iloc[0]
    for raca in RACAS:
        original = sub.loc[(sub['UF'] == uf) & (sub['RACA'] == raca)].iloc[0]
        if int(row[f'{raca} — n']) != int(original['Notificações (n)']):
            raise AssertionError(f'Numerador inconsistente para {uf}/{raca}.')
        esperado = taxa_ic_br(original)
        mostrado = str(row[f'{raca} — taxa padronizada (IC95%)']).rstrip('†')
        if esperado != mostrado:
            raise AssertionError(f'Taxa ou IC inconsistentes para {uf}/{raca}.')

print('\nSCRIPT 05 CONCLUÍDO — TABELA SUPLEMENTAR S1')
print(f'Entrada: {ARQUIVO_FONTE}')
print(f'UFs: {len(ORDEM_UF)} | grupos raciais: {len(RACAS)} | registros editoriais: {len(publicacao)}')
print('Numeração nacional — diferenças Brasil versus UFs:', controle_uf)
print(f'Excel: {ARQ_XLSX}')
print(f'CSV editorial: {ARQ_CSV}')
print('Nenhuma taxa ou IC95% foi recalculado: os resultados foram reproduzidos do Script 03.')
