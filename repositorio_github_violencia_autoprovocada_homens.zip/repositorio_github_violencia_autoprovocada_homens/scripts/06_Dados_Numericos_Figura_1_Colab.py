# ===============================================================
# SCRIPT 06 — DADOS NUMÉRICOS EXATOS DA FIGURA 1
# SINAN | Homens | Lesão autoprovocada | Brasil, 2015–2024
# Executar em uma célula do Google Colab.
# NÃO utiliza a planilha de taxas de 2022 e NÃO modifica o Parquet.
# ===============================================================

from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq

ARQUIVO = Path('/content/SINAN_VIOLENCIA_2015_2024.parquet')
PASTA_SAIDA = Path('/content/RESULTADOS_ARTIGO/04_figura1')
PASTA_SAIDA.mkdir(parents=True, exist_ok=True)

if not ARQUIVO.is_file():
    raise FileNotFoundError(f'Parquet não encontrado: {ARQUIVO}')

COLUNAS = ['ANO_ARQUIVO', 'CS_SEXO', 'LES_AUTOP', 'CS_RACA']
parquet = pq.ParquetFile(str(ARQUIVO))
faltantes = set(COLUNAS).difference(parquet.schema_arrow.names)
if faltantes:
    raise ValueError(f'Colunas ausentes no Parquet: {sorted(faltantes)}')


def codigo(s):
    return s.astype('string').str.strip().str.upper().fillna('')

# Lê somente quatro colunas, em lotes, sem materializar o banco inteiro.
contagens = []
selecionadas = 0
for lote in parquet.iter_batches(batch_size=150_000, columns=COLUNAS):
    bloco = lote.to_pandas()
    mascara = (codigo(bloco['CS_SEXO']) == 'M') & (codigo(bloco['LES_AUTOP']) == '1')
    bloco = bloco.loc[mascara, ['ANO_ARQUIVO', 'CS_RACA']].copy()
    if bloco.empty:
        continue
    selecionadas += len(bloco)

    bloco['Ano'] = pd.to_numeric(bloco['ANO_ARQUIVO'], errors='coerce')
    rc = codigo(bloco['CS_RACA'])
    bloco['Raça/cor'] = rc.map({
        '1': 'Brancos', '2': 'Negros', '4': 'Negros',
        '5': 'Indígenas', '3': 'Amarelos'
    }).fillna('Raça/cor ignorada ou inválida')
    contagens.append(
        bloco.groupby(['Ano', 'Raça/cor'], dropna=False).size().rename('n').reset_index()
    )

if not contagens:
    raise RuntimeError('Nenhuma notificação encontrada: verifique os filtros de sexo e lesão.')

agrupado = pd.concat(contagens, ignore_index=True)
agrupado = agrupado.groupby(['Ano', 'Raça/cor'], dropna=False)['n'].sum().reset_index()
invalidos = int(agrupado.loc[agrupado['Ano'].isna() | ~agrupado['Ano'].between(2015, 2024), 'n'].sum())
if invalidos:
    raise ValueError(f'Foram encontradas {invalidos} notificações com ano ausente/fora de 2015–2024.')

agrupado['Ano'] = agrupado['Ano'].astype(int)
anos = pd.Index(range(2015, 2025), name='Ano')
ordem = ['Brancos', 'Negros', 'Indígenas', 'Amarelos', 'Raça/cor ignorada ou inválida']
tabela = (
    agrupado.pivot(index='Ano', columns='Raça/cor', values='n')
            .reindex(index=anos, columns=ordem, fill_value=0)
            .fillna(0).astype(int)
)
tabela['Total de notificações'] = tabela[ordem].sum(axis=1)
tabela['Total dos três grupos da figura'] = tabela[['Brancos', 'Negros', 'Indígenas']].sum(axis=1)

# Dados exatos mostrados nos três painéis da Figura 1.
dados_figura = tabela[['Brancos', 'Negros', 'Indígenas']].copy()

# Variações anuais, em pontos percentuais relativos ao ano anterior.
variacao_anual = dados_figura.pct_change().mul(100).round(2)
variacao_anual['Total de notificações'] = tabela['Total de notificações'].pct_change().mul(100).round(2)

# Comparações úteis para a redação dos Resultados.
comparacoes = []
for grupo in ['Brancos', 'Negros', 'Indígenas', 'Total de notificações']:
    serie = tabela[grupo]
    for a, b in [(2015, 2024), (2019, 2020), (2020, 2024), (2022, 2024)]:
        inicial, final = int(serie.loc[a]), int(serie.loc[b])
        comparacoes.append({
            'Grupo': grupo, 'Ano inicial': a, 'Ano final': b,
            'Notificações no início (n)': inicial,
            'Notificações no fim (n)': final,
            'Diferença absoluta (n)': final - inicial,
            'Variação percentual (%)': round((final / inicial - 1) * 100, 2) if inicial else None
        })
comparacoes = pd.DataFrame(comparacoes)

controles = pd.DataFrame([
    ['Registros totais do Parquet (metadados)', int(parquet.metadata.num_rows)],
    ['Notificações com CS_SEXO=M e LES_AUTOP=1', int(selecionadas)],
    ['Soma dos totais de 2015–2024', int(tabela['Total de notificações'].sum())],
    ['Notificações de 2022', int(tabela.loc[2022, 'Total de notificações'])],
    ['Brancos na série', int(tabela['Brancos'].sum())],
    ['Negros na série', int(tabela['Negros'].sum())],
    ['Indígenas na série', int(tabela['Indígenas'].sum())],
], columns=['Verificação', 'Resultado'])

assert int(tabela['Total de notificações'].sum()) == selecionadas, 'Totais inconsistentes.'
assert int(tabela['Total de notificações'].sum()) == int(tabela[ordem].to_numpy().sum()), 'Erro na agregação racial.'

# Exportação com n e percentuais numéricos (sem substituir números por strings).
xlsx = PASTA_SAIDA / 'Dados_exatos_Figura_1_2015_2024.xlsx'
csv = PASTA_SAIDA / 'Dados_exatos_Figura_1_2015_2024.csv'
with pd.ExcelWriter(xlsx, engine='openpyxl') as writer:
    dados_figura.reset_index().to_excel(writer, sheet_name='Dados_Figura_1', index=False)
    tabela.reset_index().to_excel(writer, sheet_name='Serie_completa', index=False)
    variacao_anual.reset_index().to_excel(writer, sheet_name='Variacao_anual_pct', index=False)
    comparacoes.to_excel(writer, sheet_name='Variacoes_para_redacao', index=False)
    controles.to_excel(writer, sheet_name='Controles', index=False)

dados_figura.reset_index().to_csv(csv, index=False, sep=';', encoding='utf-8-sig')

# Visualização imediata no Colab: números com separador de milhar brasileiro.
def pt_n(n):
    return f'{int(n):,}'.replace(',', '.')

exibicao = dados_figura.copy()
for col in exibicao.columns:
    exibicao[col] = exibicao[col].map(pt_n)
print('\nFIGURA 1 — NÚMEROS EXATOS DE NOTIFICAÇÕES POR ANO E RAÇA/COR')
print(exibicao.to_string())

print('\nRESUMO PARA A REDAÇÃO (VARIAÇÃO PERCENTUAL)')
for _, row in comparacoes.iterrows():
    p = row['Variação percentual (%)']
    pct = f'{p:+.2f}%'.replace('.', ',') if pd.notna(p) else 'não calculável'
    print(f"{row['Grupo']}: {row['Ano inicial']}–{row['Ano final']} | "
          f"{pt_n(row['Notificações no início (n)'])} → "
          f"{pt_n(row['Notificações no fim (n)'])} | {pct}")

print('\nCONTROLES')
for _, row in controles.iterrows():
    print(f"- {row['Verificação']}: {pt_n(row['Resultado'])}")

if selecionadas != 334_638 or int(tabela.loc[2022, 'Total de notificações']) != 41_710:
    print('\nATENÇÃO: totais diferentes dos obtidos anteriormente (334.638 no período e 41.710 em 2022).')
    print('Verifique o Parquet e os critérios de seleção antes de utilizar os números no artigo.')
else:
    print('\n✓ Totais principais conferem com as análises anteriores.')

print(f'\nExcel gerado: {xlsx}')
print(f'CSV gerado:   {csv}')
